#ifndef INC_SAVE_H_
#define INC_SAVE_H_

#include "main.h"

void save_init(void);
void save_run(void);
void save_cmd(char *cmd);

int save_home(void);
int save_go(int col, int dan);
void save_stop(void);
int save_busy(void);

/* item.c�� ����. save_result: 0=������ 1=���� -1=���� */
int save_result(void);
int save_grid_x(void);
int save_grid_y(void);

void save_abort(void);
int save_pause(void);
int save_paused(void);
int save_resume(void);
int save_ready(void);

#endif
