Core/Src/net.o: ../Core/Src/net.c ../Core/Inc/net.h ../Core/Inc/main.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h \
 ../Core/Inc/stm32f4xx_hal_conf.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f446xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_can.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h \
 ../Core/Inc/cli.h ../Core/Inc/button.h ../Core/Inc/motor.h \
 ../Core/Inc/rot_test.h ../Core/Inc/rfid.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h \
 ../Core/Inc/FreeRTOSConfig.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/list.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h \
 ../Core/Inc/fram.h ../Core/Inc/spi.h ../Core/Inc/i2c.h \
 ../Core/Inc/usart.h ../Drivers/Ethernet/socket.h \
 ../Drivers/Ethernet/wizchip_conf.h ../Drivers/Ethernet/./W6100/w6100.h \
 ../Drivers/Ethernet/wizchip_conf.h
../Core/Inc/net.h:
../Core/Inc/main.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h:
../Core/Inc/stm32f4xx_hal_conf.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f446xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_can.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h:
../Core/Inc/cli.h:
../Core/Inc/button.h:
../Core/Inc/motor.h:
../Core/Inc/rot_test.h:
../Core/Inc/rfid.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h:
../Core/Inc/FreeRTOSConfig.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h:
../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/list.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h:
../Core/Inc/fram.h:
../Core/Inc/spi.h:
../Core/Inc/i2c.h:
../Core/Inc/usart.h:
../Drivers/Ethernet/socket.h:
../Drivers/Ethernet/wizchip_conf.h:
../Drivers/Ethernet/./W6100/w6100.h:
../Drivers/Ethernet/wizchip_conf.h:
