/*
 * net.c
 *
 * 프레임  STX | 01 | ACK 또는 NAK 또는 없음 | 내용 | ETX
 * 단계    READY 0도 정렬 -> XY 이동 -> TILT 기울임 -> TURN 도착
 *         01MI 는 TURN 에서 끝. 01PO 는 BACK -> CENTER 로 되돌아온다
 * 회전과 XY 는 전류가 몰리지 않게 겹치지 않는다.
 * 회전 명령은 1초 간격으로만 다시 쏜다. 매 주기 쏘면 가속이 리셋된다.
 * x y r l c 는 CLI 시험용이라 프레임 없이 UART3 에만 찍는다.
 */
#include "net.h"
#include "cli.h"
#include "button.h"
#include "motor.h"
#include "rot_test.h"
#include "rfid.h"
#include "fram.h"
#include "spi.h"
#include "i2c.h"
#include "usart.h"
#include "socket.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>
#include <string.h>

#define NET_SPI   hspi1
#define SOCK      0
#define PORT      2500

#define TOLERANCE 50      /* 이만큼도 안 움직이면 멈춘 것으로 본다 */
#define START_MS  1000    /* 명령 걸고 이만큼은 무조건 기다린다 */
#define LIMIT_MS  10000   /* 이 시간 안에 못 끝내면 실패로 본다 */
#define RETRY_MS  1000    /* 이 간격으로만 이동 명령을 다시 쏜다 */
#define STUCK_MS  2000    /* 이만큼 위치가 안 변하면 걸린 것으로 본다 */
#define ROT_ID    2       /* rot_test.c 의 MKS 주소 */
#define ROT_PROT  0x3E    /* MKS 보호 상태. 1 이면 걸림 */
#define REV_PULSE 1000    /* 1회전 펄스 */
#define REV_MM    160     /* 1회전 이동 mm. 폴리 지름 50.93 의 원주 */
#define XY_GEAR   5       /* MD60모터에 들어있는 감속비 5:1 */
#define MAX_RPM   3000


/* 공유기 대역에 맞춰 여기만 고친다 */
#define IP        {172, 20, 0, 101}   /* 이 보드 DIP */
#define MASK      {255, 255, 255, 0}
#define GATE      {0, 0, 0, 0}

static State state = STATE_W;   /* 기본 상태는 대기중 */
static Step step = STEP_STOP;   /* 기본 상태는 멈춘 상태 */
static Move move;               /* 지금 하고 있는 동작 하나 */
static uint32_t step_time;      /* 지금 단계가 시작된 시각 */
static uint32_t send_time;      /* 회전 명령을 마지막에 쏜 시각 */
static char line[128];          /* 01FP 저장 값이 길어서 늘렸습니다 */
static int line_len;

static char alarm[16];          /* 지금 걸린 알람 상세코드 */
static int was_pause;           /* PG1 해제를 보려고 지난 pause 를 기억한다 */
static int start_x, start_y;    /* 이동 시작 위치. 걸림 판정에 쓴다 */
static int pos_x, pos_y;        /* xy_stop 이 읽은 현재 위치 */
static int x_ok, y_ok;          /* 축별 목표 도달 여부 */

/* ===== 응답 ===== */

/* 부팅 로그는 UART3 으로만 */
void print(const char *s) {
	HAL_UART_Transmit(&huart3, (uint8_t*) s, strlen(s), 100);
}

/* UART3 은 보기 좋게 개행까지, TCP 는 프레임만 */
void reply(const char *s) {
	uint8_t frame[132];
	int n = strlen(s);

	frame[0] = STX;
	memcpy(frame + 1, s, n);
	frame[n + 1] = ETX;
	frame[n + 2] = '\r';
	frame[n + 3] = '\n';

	HAL_UART_Transmit(&huart3, frame, n + 4, 100);
	if (getSn_SR(SOCK) == SOCK_ESTABLISHED)
		send(SOCK, frame, n + 4);
}

/* 01 뒤에 제어문자를 넣어 보낸다. c 가 0 이면 제어문자 없이 */
static void say(char c, const char *s) {
	char msg[128];

	if (c)
		snprintf(msg, sizeof(msg), "01%c%s", c, s);
	else
		snprintf(msg, sizeof(msg), "01%s", s);
	reply(msg);
}

/* 일시정지 알림. F 만재 M 버튼 S RFID T 걸림 */
void pause_msg(char why) {
	char msg[16];
	snprintf(msg, sizeof(msg), "PAUSE:%c", why);
	say(0, msg);
}

/* ===== W6100 SPI ===== */

static void cs_on(void) {
	HAL_GPIO_WritePin(W610_CS_GPIO_Port, W610_CS_Pin, GPIO_PIN_RESET);
}
static void cs_off(void) {
	HAL_GPIO_WritePin(W610_CS_GPIO_Port, W610_CS_Pin, GPIO_PIN_SET);
}
static uint8_t spi_rb(void) {
	uint8_t b;
	HAL_SPI_Receive(&NET_SPI, &b, 1, 100);
	return b;
}
static void spi_wb(uint8_t b) {
	HAL_SPI_Transmit(&NET_SPI, &b, 1, 100);
}
static void spi_rbuf(uint8_t *buf, datasize_t n) {
	HAL_SPI_Receive(&NET_SPI, buf, n, 1000);
}
static void spi_wbuf(uint8_t *buf, datasize_t n) {
	HAL_SPI_Transmit(&NET_SPI, buf, n, 1000);
}

/* MAC 은 EEPROM 에서 읽고, NET 락을 풀어야 IP 가 써진다 */
static void net_init(void) {
	uint8_t size[8] = { 2, 2, 2, 2, 2, 2, 2, 2 };
	wiz_NetInfo net = { .ip = IP, .sn = MASK, .gw = GATE,
			.ipmode = NETINFO_STATIC_V4 };
	int i;

	HAL_I2C_Mem_Read(&hi2c1, 0xA0, 0xFA, I2C_MEMADD_SIZE_8BIT, net.mac, 6, 100);
	HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_RESET);
	HAL_Delay(10);
	HAL_GPIO_WritePin(W610_RST_GPIO_Port, W610_RST_Pin, GPIO_PIN_SET);
	HAL_Delay(100);

	reg_wizchip_cs_cbfunc(cs_on, cs_off);
	reg_wizchip_spi_cbfunc(spi_rb, spi_wb, spi_rbuf, spi_wbuf);
	wizchip_init(size, size);

	NETUNLOCK();
	wizchip_setnetinfo(&net);
	PHYUNLOCK();
	setPHYCR0(PHYCR0_AUTO);
	setPHYCR1(PHYCR1_RST);
	HAL_Delay(300);

	for (i = 0; i < 50 && !(getPHYSR() & PHYSR_LNK); i++)
		HAL_Delay(100);
}

/* ===== 동작 ===== */

/* mm 을 X/Y 모터 펄스로 */
static int mm_to_pulse(int mm) {
	return mm * REV_PULSE * XY_GEAR / REV_MM;
}

/* 각도를 회전축 펄스로 */
static int deg_to_pulse(int deg) {
	return deg * MKS_REV * ROT_GEAR / 360;
}

/* 오차 안이면 1 */
static int same(int a, int b) {
	return a - b <= TOLERANCE && b - a <= TOLERANCE;
}

/* 다음 단계로. 대기 시간은 여기서부터 다시 센다 */
static void next(Step s) {
	step = s;
	step_time = HAL_GetTick();
}

/* ===== 알람 ===== */

static int job_stop(void);

/* 상세코드 앞글자로 상위 알람 코드를 고른다 */
static const char* alarm_group(void) {
	return alarm[0] == 'X' ? "A_02" : alarm[0] == 'Y' ? "A_03" :
			alarm[0] == 'R' ? "A_04" : "A_09";
}

/* 알람을 세우고 멈춘다. 먼저 걸린 알람은 덮지 않는다 */
static void alarm_on(const char *code) {
	if (alarm[0])
		return;
	snprintf(alarm, sizeof(alarm), "%s", code);
	job_stop();
	say(NAK, code);
	pause_on('A');
}

/* H0B_34 고장이 있으면 그걸 쓰고, 없으면 부른 쪽이 준 why 를 쓴다 */
static void axis_alarm(Motor *m, const char *why) {
	char code[16];
	uint16_t v;

	if (!motor_alarm(m, &v))
		why = "COMM";
	else if (v == 410)               /* 저전압 */
		why = "LOW_V";
	else if (v == 620 || v == 630)   /* 과부하, 구속 */
		why = "LOAD";
	else if (v == 0x0B00)            /* 위치편차 초과 */
		why = "POS";
	else if (v == 601)               /* 원점복귀 시간초과 */
		why = "HOME";
	else if (v)
		why = "ALM";

	snprintf(code, sizeof(code), "%s_%s",
			m == &motorX ? "X" : "Y", why);
	alarm_on(code);
}

/* 회전축은 보호 상태를 먼저 본다 */
static void rot_alarm(const char *why) {
	int v;

	if (mks_read(ROT_ID, ROT_PROT, 1, &v) && v == 1)
		alarm_on("ROT_LOAD");
	else
		alarm_on(why);
}

/* 회전 명령. RS485 응답이 유실되면 명령도 안 들어갔을 수 있다.
   10ms 마다 다시 쏘면 가속이 처음부터 다시 시작되므로 간격을 둔다 */
static int turn_to(int axis) {
	send_time = HAL_GetTick();
	if (mks_move(move.tilt_speed, axis))
		return 1;
	rot_alarm("ROT_FAIL");     /* F5 응답이 0 이면 명령이 안 먹었다 */
	return 0;
}

/* 아직 도착 전이면 간격을 보고 다시 쏜다 */
static void turn_again(int axis) {
	if (HAL_GetTick() - send_time >= RETRY_MS)
		turn_to(axis);
}

/* 이동 직전 위치를 남긴다. 걸림 판정의 기준이 된다 */
static void mark_start(void) {
	motor_pos(&motorX, &start_x);
	motor_pos(&motorY, &start_y);
}

/* 개별 이동과 MI/PO 의 목표 위치 확인. 통신이 끊기면 -1 */
static int xy_stop(void) {
	if (!motor_pos(&motorX, &pos_x)) {
		axis_alarm(&motorX, "COMM");
		return -1;
	}
	if (!motor_pos(&motorY, &pos_y)) {
		axis_alarm(&motorY, "COMM");
		return -1;
	}

	if (move.mode == MODE_HOME) {       /* 원점은 좌표가 0 이어야 한다 */
		x_ok = pos_x == 0;
		y_ok = pos_y == 0;
	} else {
		/* Y 는 motor_move 가 뒤집어 보내니 여기도 마이너스 */
		x_ok = same(pos_x, mm_to_pulse(move.x_mm));
		y_ok = same(pos_y, -mm_to_pulse(move.y_mm));
	}

	if (move.mode == MODE_X)
		return x_ok;
	if (move.mode == MODE_Y)
		return y_ok;

	return x_ok && y_ok;
}

/* 못 간 축을 골라 알람을 세운다. 시작 위치 그대로면 걸린 것이다.
   only 면 걸림만 보고 시간 초과는 넘긴다 */
static void xy_fail(int only) {
	int x = !x_ok && move.mode != MODE_Y;

	if (same(x ? pos_x : pos_y, x ? start_x : start_y))
		axis_alarm(x ? &motorX : &motorY, "LOAD");
	else if (!only)
		axis_alarm(x ? &motorX : &motorY,
				move.mode == MODE_HOME ? "HOME" : "POS");
}

/* x y r l c 결과. 프레임 없이 UART3 에만 찍는다 */
static void done(int ok, const char *name) {
	char msg[24];

	if (ok) {
		state = STATE_W;
		next(STEP_STOP);
	}
	snprintf(msg, sizeof(msg), "%s %s\r\n", name, ok ? "OK" : "ERR");
	print(msg);
}

/* MI / PO / 원점 완료 */
static void job_end(void) {
	char msg[32];

	state = STATE_W;
	next(STEP_STOP);

	if (move.mode == MODE_HOME) {
		say(0, "IE_1");
		return;
	}
	if (move.full)                 /* 만재 칸이라 틸트를 건너뛰었다 */
		pause_on('F');
	else if (move.stuck)           /* 기울였는데도 안 빠졌다 */
		pause_on('T');

	if (pause)                     /* 멈춘 채로 끝났으면 완료가 아니다 */
		return;

	snprintf(msg, sizeof(msg),
			move.mode == MODE_IN ? "AI_%d_%d_%d" : "EO_%d_%d_%d",
			move.rack, move.prev_x, move.prev_y);
	say(0, msg);
}

static int job_stop(void) {
	int ok;

	state = STATE_P;
	next(STEP_STOP);   /* 이 순서로 해야 다음 동작을 실행하지 않는다 */
	ok = motor_stop(&motorX);
	ok = motor_stop(&motorY) && ok;
	return mks_stop() && ok;
}

/* 원점센서를 만나면 각자 멈추고 그 지점을 원점으로 잡는다 */
static int job_home(void) {
	int x, y, m;

	move.mode = MODE_HOME;
	x = motor_home_on(&motorX);
	y = motor_home_on(&motorY);
	m = mks_home();

	if (!x)
		axis_alarm(&motorX, "HOME");
	else if (!y)
		axis_alarm(&motorY, "HOME");
	else if (!m)
		alarm_on("ROT_HOME");
	else {
		mark_start();
		state = STATE_I;
		next(STEP_XY);
		return 1;
	}
	return 0;
}

/* 렉_열_단_XY%_틸트%_시작지연ms_복귀대기10ms */
static int job_go(char *s, int mode) {
	int rack, col, row, xy, tilt;
	int spare, angle, center, saved;

	if (sscanf(s, "%d_%d_%d_%d_%d_%d_%d", &rack, &col, &row, &xy, &tilt,
			&move.tilt_delay, &move.back_delay) != 7)
		return 0;
	if (!rot_load(rack, &spare, &angle, &center, &saved))
		return 0;

	/* MI 는 입고 좌표, PO 는 출고 좌표를 fram 에서 읽는다 */
	pos_load(rack, mode == MODE_IN ? IN_X : OUT_X, col, &move.x_mm);
	pos_load(rack, mode == MODE_IN ? IN_Y : OUT_Y, row, &move.y_mm);

	move.mode = mode;
	move.rack = rack;
	move.prev_x = col;
	move.prev_y = row;
	move.stuck = 0;
	move.speed = xy * MAX_RPM / 100;         /* % 를 rpm 으로 */
	move.tilt_speed = tilt * MAX_RPM / 100;
	move.back_delay *= 10;                   /* 10ms 단위로 들어온다 */

	/* MI 는 왼쪽 10도 고정, PO 는 오른쪽으로 기운다 */
	move.tilt = deg_to_pulse(mode == MODE_IN ? 10 : -angle);

	/* 그 단이 만재면 각도를 0으로 두어 틸트만 건너뛴다 */
	move.full = 0;
	if (mode == MODE_OUT && (full_get() & 1 << (row - 1))) {
		move.tilt = 0;
		move.full = 1;
	}

	if (!turn_to(0))                         /* 회전축을 0도로 먼저 */
		return 0;
	state = STATE_R;
	next(STEP_READY);
	return 1;
}

/* x / y 수동 이동 */
static int job_axis(char axis, int mm, int rpm) {
	Motor *m = axis == 'x' ? &motorX : &motorY;

	if (axis == 'x')
		move.x_mm = mm;
	else
		move.y_mm = mm;
	move.mode = axis == 'x' ? MODE_X : MODE_Y;

	mark_start();
	if (!motor_move(m, rpm, mm_to_pulse(mm))) {
		axis_alarm(m, "COMM");
		return 0;
	}
	state = STATE_R;
	next(STEP_XY);
	return 1;
}

/* r / l / c 수동 회전. 목표를 한 번만 계산해 그대로 보낸다 */
static int job_turn(int deg, int rpm, int mode) {
	move.tilt = deg_to_pulse(deg);
	move.mode = mode;

	if (!mks_move(rpm, move.tilt)) {
		rot_alarm("ROT_FAIL");
		return 0;
	}
	state = STATE_R;
	next(STEP_TURN);
	return 1;
}

/* PG1 이나 01D_1 로 일시정지가 풀린 순간을 잡는다.
   알람이면 원점부터, 만재면 건너뛴 틸트를 이어서 한다 */
static void pause_watch(void) {
	int l, r, c, rpm;

	if (was_pause && !pause) {
		if (alarm[0]) {
			motor_reset(&motorX);        /* 드라이버 고장부터 지운다 */
			motor_reset(&motorY);
			alarm[0] = 0;                /* 지워야 새 알람이 선다 */
			job_home();                  /* 좌표를 못 믿으니 원점으로 */
		} else if (move.full && rot_load(move.rack, &l, &r, &c, &rpm)) {
			move.full = 0;
			move.tilt = deg_to_pulse(-r);
			state = STATE_R;
			next(STEP_TILT);
		}
	}
	was_pause = pause;
}

/* 회전축이 axis 에 올 때까지 기다린다. 도착하면 1 */
static int rot_wait(int axis) {
	if (mks_done(axis))
		return 1;
	if (HAL_GetTick() - step_time > LIMIT_MS)
		rot_alarm("ROT_FAIL");
	else
		turn_again(axis);            /* 응답 유실 대비 재전송 */
	return 0;
}

/* XY 가 목표에 올 때까지 기다린다. 도착하면 1 */
static int xy_wait(void) {
	uint32_t wait = HAL_GetTick() - step_time;
	int ok = xy_stop();

	if (ok)                          /* 도착 1, 통신 끊김 -1 */
		return ok > 0;
	if (wait > LIMIT_MS)
		xy_fail(0);
	else if (wait > STUCK_MS)
		xy_fail(1);
	return 0;
}

/* CLI 수동 명령이면 그 이름, 아니면 0 */
static const char* manual_name(void) {
	switch (move.mode) {
	case MODE_X:      return "x";
	case MODE_Y:      return "y";
	case MODE_RIGHT:  return "r";
	case MODE_LEFT:   return "l";
	case MODE_CENTER: return "c";
	default:          return 0;
	}
}

/* 10ms 마다 현재 동작 단계를 확인한다 */
static void job_run(void) {
	uint32_t wait = HAL_GetTick() - step_time;   /* 이 단계에 머문 시간 */
	const char *name;

	/* 비상정지 램프는 button.c 가 잡으므로 알람만 세운다 */
	if (estop) {
		if (!alarm[0])
			snprintf(alarm, sizeof(alarm), "ESTOP");
		return;
	}
	if (!strcmp(alarm, "ESTOP"))
		alarm[0] = 0;

	pause_watch();

	switch (step) {
	case STEP_READY:                 /* 0도 정렬을 기다렸다 XY 출발 */
		if (wait < START_MS || !rot_wait(0))
			break;
		mark_start();
		motor_move(&motorX, move.speed, mm_to_pulse(move.x_mm));
		motor_move(&motorY, move.speed, mm_to_pulse(move.y_mm));
		next(STEP_XY);
		break;

	case STEP_XY:                    /* 목표 열/단 도착을 기다린다 */
		if (wait < START_MS || !xy_wait())
			break;
		name = manual_name();
		if (name)                    /* x, y 수동 이동은 여기서 끝 */
			done(1, name);
		else if (move.mode == MODE_HOME) {
			if (mks_done(0))         /* 회전축까지 원점이면 끝 */
				job_end();
		} else if (!move.tilt)       /* 만재면 틸트 없이 끝 */
			job_end();
		else
			next(STEP_TILT);
		break;

	case STEP_TILT:                  /* 지연 뒤 목표 각도로 */
		if (wait < (uint32_t) move.tilt_delay)
			break;
		turn_to(move.tilt);
		next(STEP_TURN);
		break;

	case STEP_TURN:                  /* 목표 각도 도착을 기다린다 */
		if (!rot_wait(move.tilt))
			break;
		name = manual_name();
		if (name)                    /* r, l, c 수동 회전은 여기서 끝 */
			done(1, name);
		else if (move.mode == MODE_IN)
			job_end();               /* 01MI 는 여기서 끝 */
		else {
			/* 기울였는데도 그대로면 물건이 안 내려간 것 */
			if (full_read() & 1 << (move.prev_y - 1))
				move.stuck = 1;
			next(STEP_BACK);         /* 01PO 는 복귀로 */
		}
		break;

	case STEP_BACK:                  /* 지연 뒤 원점으로 되돌린다 */
		if (wait < (uint32_t) move.back_delay)
			break;
		turn_to(0);
	//turn_to(deg_to_pulse(-2));        /* 여기서 2도로 쏘고  */
		next(STEP_CENTER);
		break;

	case STEP_CENTER:                /* 원점 도착을 기다린다 */
	//  if (rot_wait(deg_to_pulse(-2)))   /* 여기도 2도로 기다려야 한다 *
		if (rot_wait(0))
			job_end();
		break;

	default:
		break;
	}
}
/* ===== 명령 ===== */

/* 01FP_렉_축 조회. 축 1=입고X 2=입고Y 3=틸트 4=출고X 5=출고Y */
static void pos_show(int rack, int axis) {
	char msg[96];
	int v[4], a = axis < 3 ? axis : axis - 1;
	int i, len;

	if (axis == 3) {
		rot_load(rack, &v[0], &v[1], &v[2], &v[3]);
		snprintf(msg, sizeof(msg), "FP_%d_3_%d_%d_%d_%d",
				rack, v[0], v[1], v[2], v[3]);
		say(ACK, msg);
		return;
	}
	len = snprintf(msg, sizeof(msg), "FP_%d_%d", rack, axis);
	for (i = 1; i <= pos_count(a); i++) {
		pos_load(rack, a, i, &v[0]);
		len += snprintf(msg + len, sizeof(msg) - len, "_%d", v[0]);
	}
	say(ACK, msg);
}

/* 01FP_렉_축_값... 저장 또는 조회 */
static void save_pos(char *s) {
	int rack, axis, count, pos[8];

	count = sscanf(s, "01FP_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d",
			&rack, &axis,
			&pos[0], &pos[1], &pos[2], &pos[3],
			&pos[4], &pos[5], &pos[6], &pos[7]);

	if (count == 1)                    /* 01FP_렉 : 축 1~5 전부 */
		for (axis = 1; axis <= 5; axis++)
			pos_show(rack, axis);
	else if (count == 2)               /* 01FP_렉_축 */
		pos_show(rack, axis);
	/* 틸트는 L, R, C, rpm 네 개. 내부 번호에 회전이 없어서
	   프로토콜의 4와 5 에서 1 을 뺀다 */
	else if (axis == 3
			? count == 6 && rot_save(rack, pos[0], pos[1], pos[2], pos[3])
			: pos_save(rack, axis < 3 ? axis : axis - 1, pos, count - 2))
		say(ACK, "FP");
	else
		say(NAK, "FP_save_fail");
}

/* 01FS_1 조회 또는 01FS_1_S_X_Y 저장 */
static void save_cfg(char *s) {
	char msg[48], type;
	int rack, inx, iny, outx, outy;

	if (!strcmp(s, "1")) {
		cfg_load(&rack, &inx, &iny, &outx, &outy);
		snprintf(msg, sizeof(msg), "FS_1_S_%d_%d_%d_%d",
				inx, iny, outx, outy);
		say(ACK, msg);
		return;
	}
	if (sscanf(s, "%d_%c_%d_%d_%d_%d",
			&rack, &type, &inx, &iny, &outx, &outy) == 6
			&& rack == 1 && type == 'S'
			&& cfg_save(rack, inx, iny, outx, outy))
		say(ACK, "FS");
	else
		say(NAK, "FS_save_fail");
}

/* 01MI / 01PO 시작. 수락하면 받은 명령을 그대로 되돌린다 */
static void go_start(char *s, int mode, const char *name) {
	char msg[48];

	if (!card_ok) {                    /* 카드가 없으면 움직이지 않는다 */
		snprintf(msg, sizeof(msg), "%s_no_rfid", name);
		say(NAK, msg);
		pause_on('S');
		return;
	}
	if (job_go(s, mode)) {
		snprintf(msg, sizeof(msg), "%s_%s", name, s);
		say(ACK, msg);
	} else if (!alarm[0]) {            /* 알람이면 그쪽에서 이미 보냈다 */
		snprintf(msg, sizeof(msg), "%s_move_fail", name);
		say(NAK, msg);
	}
}

/* 01C 상태 조회 */
static void show_state(void) {
	char msg[64], f_msg[16] = "&S";
	int f = full_get();

	if (f)
		snprintf(f_msg, sizeof(f_msg), "&F_1_%d%d%d%d",
				!!(f & 1), !!(f & 2), !!(f & 4), !!(f & 8));

	if (alarm[0])
		snprintf(msg, sizeof(msg), "S_1_%s%s : %s",
				alarm_group(), f_msg, alarm);
	else
		snprintf(msg, sizeof(msg), "S_1_%c%s",
				pause ? STATE_P : state, f_msg);
	say(ACK, msg);
}

/* 동작중에도 되는 명령이면 1 */
static int always_ok(char *s) {
	return !strcmp(s, "01S_1") || !strcmp(s, "01D_1")
			|| !strcmp(s, "01C") || !strcmp(s, "01R");
}

/* TCP 와 UART3 CLI 가 같이 쓴다 */
void net_cmd(char *s) {
	char msg[64];
	int value, speed;

	if ((step != STEP_STOP || pause) && !always_ok(s)) {
		say(NAK, "moving");
		return;
	}

	if (strncmp(s, "01MI_", 5) == 0)
		go_start(s + 5, MODE_IN, "MI");
	else if (strncmp(s, "01PO_", 5) == 0)
		go_start(s + 5, MODE_OUT, "PO");

	else if (sscanf(s, "x_%d_%d", &value, &speed) == 2)
		done(job_axis('x', value, speed), "x");
	else if (sscanf(s, "y_%d_%d", &value, &speed) == 2)
		done(job_axis('y', value, speed), "y");
	else if (sscanf(s, "r_%d_%d", &value, &speed) == 2)
		done(job_turn(-value, speed, MODE_RIGHT), "r");  /* 오른쪽 음수 */
	else if (sscanf(s, "l_%d_%d", &value, &speed) == 2)
		done(job_turn(value, speed, MODE_LEFT), "l");    /* 왼쪽 양수 */
	else if (sscanf(s, "c_%d", &speed) == 1)
		done(job_turn(0, speed, MODE_CENTER), "c");      /* 0도로 */

	else if (strncmp(s, "01FP_", 5) == 0)
		save_pos(s);
	else if (strncmp(s, "01FS_", 5) == 0)
		save_cfg(s + 5);
	else if (strcmp(s, "01I") == 0) {           /* 원점 이동 */
		if (job_home())
			say(ACK, "I");
		else if (!alarm[0])
			say(NAK, "I_move_fail");
	}
	else if (strcmp(s, "01S_1") == 0)           /* 전체 정지 */
		job_stop() ? say(ACK, "S") : say(NAK, "S_stop_fail");
	else if (strcmp(s, "01D_1") == 0)           /* 만재 해제 */
		full_release() ? say(ACK, "D_1") : say(NAK, "D_full");

	else if (strcmp(s, "01C") == 0)
		show_state();
	else if (strcmp(s, "01R") == 0)
		Rfid_Request();

	else {
		snprintf(msg, sizeof(msg), "bad_cmd_%s", s);
		say(NAK, msg);
	}
}
/* ===== TCP ===== */

/* STX 로 시작해 ETX 나 엔터가 올 때까지 모았다가 한 줄씩 실행한다 */
static void take(uint8_t c) {
	if (c == STX) {
		line_len = 0;
		return;
	}
	if (c == ETX || c == '\r' || c == '\n') {
		if (line_len) {
			line[line_len] = 0;
			line_len = 0;
			net_cmd(line);
		}
		return;
	}
	if (line_len < (int) sizeof(line) - 1)
		line[line_len++] = c;
}

static void serve(void) {
	uint8_t buf[64];
	int n, i;

	switch (getSn_SR(SOCK)) {
	case SOCK_CLOSED:
		socket(SOCK, Sn_MR_TCP4, PORT, 0);
		line_len = 0;
		break;
	case SOCK_INIT:
		listen(SOCK);
		break;
	case SOCK_ESTABLISHED:
		n = getSn_RX_RSR(SOCK);
		if (!n)
			break;
		if (n > (int) sizeof(buf))
			n = sizeof(buf);
		recv(SOCK, buf, n);
		for (i = 0; i < n; i++)
			take(buf[i]);
		break;
	case SOCK_CLOSE_WAIT:
		disconnect(SOCK);
		line_len = 0;
		break;
	}
}

void TM_TaskRun(void *arg) {
	int xok, yok, mok;

	(void) arg;
	button_init();
	net_init();
	print(fram_load() ? "fram ready\r\n" : "fram empty\r\n");

	xok = motor_init(&motorX);
	yok = motor_init(&motorY);
	mok = mks_init();
	print(xok ? "x ready\r\n" : "x init ERR\r\n");
	print(yok ? "y ready\r\n" : "y init ERR\r\n");
	print(mok ? "mks ready\r\n" : "mks init ERR\r\n");
	cli_start();

	if (xok && yok && mok && !estop && !job_home())
		print("home ERR\r\n");   /* 전원 넣으면 바로 원점으로 간다 */

	for (;;) {
		button_run();
		serve();
		cli_poll();
		job_run();
		vTaskDelay(pdMS_TO_TICKS(10));
	}
}
