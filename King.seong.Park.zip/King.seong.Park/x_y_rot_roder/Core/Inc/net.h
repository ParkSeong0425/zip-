/*
 * net.h
 */
#ifndef INC_NET_H_
#define INC_NET_H_

#include "main.h"

/* 프레임 문자. 터미널에는 ACK 가 - , NAK 이 ㅗ 처럼 보인다 */
#define STX       0x02    /* 명령 시작 */
#define ETX       0x03    /* 명령 끝 */
#define ACK       0x06    /* 수락 */
#define NAK       0x15    /* 거절 */

typedef enum {
	STATE_W = 'W', STATE_R = 'R', STATE_I = 'I', STATE_P = 'P'
} State;

/* READY 에서 0도 정렬을 끝낸 뒤 XY 로 간다 */
typedef enum {
	STEP_STOP,
	STEP_READY,
	STEP_XY,
	STEP_TILT,
	STEP_TURN,
	STEP_BACK,
	STEP_CENTER
} Step;

/* Move.mode 값. 숫자는 바꾸지 말 것.
   IN/OUT 의 -1/+1 은 틸트 각도 부호로 쓰고,
   RIGHT 이상은 수동 회전 판정에 쓴다 */
typedef enum {
	MODE_HOME = 0,
	MODE_IN = -1,
	MODE_OUT = 1,
	MODE_X = 2,
	MODE_Y = 3,
	MODE_RIGHT = 4,
	MODE_LEFT = 5,
	MODE_CENTER = 6
} Mode;

typedef struct {
	int x_mm, y_mm, speed;       /* X/Y 목표 mm 와 속도 */
	int tilt, tilt_speed;        /* 틸트 목표 펄스와 속도 */
	int mode;                    /* 어떤 명령인지. Mode 참고 */
	int tilt_delay, back_delay;  /* 틸트 전 지연, 복귀 전 지연 */
	int rack, prev_x, prev_y;    /* 응답에 실을 렉, 열, 단 */
	int full;                    /* 만재 칸으로 간 PO 면 1 */
	int stuck;                   /* 틸트 뒤에도 안 빠졌으면 1 */
} Move;

void print(const char *s);   /* UART3 에만. 프레임 없음 */
void reply(const char *s);   /* STX 내용 ETX 로 감싸 보낸다 */
void pause_msg(char why);    /* 01PAUSE:F M S T */
void net_cmd(char *s);       /* TCP 와 UART3 CLI 가 같이 쓴다 */

/* freertos.c 의 StartUART_Task() 가 호출한다 */
void TM_TaskRun(void *arg);

#endif
