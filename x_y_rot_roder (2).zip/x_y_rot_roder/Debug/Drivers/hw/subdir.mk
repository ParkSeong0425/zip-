################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
O_SRCS += \
../Drivers/hw/TRH033MS_ISO14443A.o \
../Drivers/hw/can.o \
../Drivers/hw/led.o 


# Each subdirectory must supply rules for building sources it contributes

