Drivers/Ethernet/socket.o: ../Drivers/Ethernet/socket.c \
 ../Drivers/Ethernet/socket.h ../Drivers/Ethernet/wizchip_conf.h \
 ../Drivers/Ethernet/./W6100/w6100.h ../Drivers/Ethernet/wizchip_conf.h \
 ../Drivers/Ethernet/W6100/w6100.h
../Drivers/Ethernet/socket.h:
../Drivers/Ethernet/wizchip_conf.h:
../Drivers/Ethernet/./W6100/w6100.h:
../Drivers/Ethernet/wizchip_conf.h:
../Drivers/Ethernet/W6100/w6100.h:
