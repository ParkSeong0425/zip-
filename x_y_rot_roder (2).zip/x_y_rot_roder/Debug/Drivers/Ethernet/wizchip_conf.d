Drivers/Ethernet/wizchip_conf.o: ../Drivers/Ethernet/wizchip_conf.c \
 ../Drivers/Ethernet/wizchip_conf.h ../Drivers/Ethernet/./W6100/w6100.h \
 ../Drivers/Ethernet/wizchip_conf.h
../Drivers/Ethernet/wizchip_conf.h:
../Drivers/Ethernet/./W6100/w6100.h:
../Drivers/Ethernet/wizchip_conf.h:
