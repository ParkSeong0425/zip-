Drivers/Ethernet/W6100/w6100.o: ../Drivers/Ethernet/W6100/w6100.c \
 ../Drivers/Ethernet/W6100/w6100.h ../Drivers/Ethernet/wizchip_conf.h \
 ../Drivers/Ethernet/./W6100/w6100.h
../Drivers/Ethernet/W6100/w6100.h:
../Drivers/Ethernet/wizchip_conf.h:
../Drivers/Ethernet/./W6100/w6100.h:
