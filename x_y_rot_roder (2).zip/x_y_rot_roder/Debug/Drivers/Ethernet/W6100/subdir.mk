################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/Ethernet/W6100/w6100.c 

OBJS += \
./Drivers/Ethernet/W6100/w6100.o 

C_DEPS += \
./Drivers/Ethernet/W6100/w6100.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/Ethernet/W6100/%.o Drivers/Ethernet/W6100/%.su Drivers/Ethernet/W6100/%.cyclo: ../Drivers/Ethernet/W6100/%.c Drivers/Ethernet/W6100/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/Ethernet -I../Drivers/Ethernet/W6100 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2 -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-Ethernet-2f-W6100

clean-Drivers-2f-Ethernet-2f-W6100:
	-$(RM) ./Drivers/Ethernet/W6100/w6100.cyclo ./Drivers/Ethernet/W6100/w6100.d ./Drivers/Ethernet/W6100/w6100.o ./Drivers/Ethernet/W6100/w6100.su

.PHONY: clean-Drivers-2f-Ethernet-2f-W6100

