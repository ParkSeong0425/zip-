/*
 * button.c
 *
 *  Created on: Jul 22, 2026
 *      Author: kotec
 *
 * 요구사항 : run 버튼 하고 pause 버튼은 50ms 이상 유지 되면 ON. OFF 하는 식으로 원해
 * 알람은 버튼을 모두 놓은 뒤 RUN을 50ms 누르면 해제하고 원점 복귀한다.
 */

#include "button.h"
#include "net.h"
#include "motor.h"
#include <stdio.h>
int alarm_get(void); void alarm_set(int code); extern volatile int card_ok;

#define BUTTON_COUNT 5   /* button_run 10ms x 5 = 50ms */

volatile int run;
volatile int pause;
volatile int estop;

static int full;        /* 감지된 만재 센서 */
static int full_pause;  /* 만재로 멈춰 있으면 1 */
static int lamp_count;  /* button_run 10ms 호출 횟수 */
static char lamp_mode;  /* R 운전, P 일시정지, E ESTOP, A 알람 */
static int tcp_mode[2], tcp_left[2], tcp_count, tcp_on, tcp_auto;
static int both_count, both_time; /* 두 버튼을 2초 안에 누른 횟수 */
static volatile char pause_reason; /* M 버튼, F 만재, S RFID */

/* F1~F4 현재 만재 입력을 비트로 읽는다 */
static int full_now(void) {
	return (HAL_GPIO_ReadPin(F1_GPIO_Port, F1_Pin) ? 0 : 1)
			| (HAL_GPIO_ReadPin(F2_GPIO_Port, F2_Pin) ? 0 : 2)
			| (HAL_GPIO_ReadPin(F3_GPIO_Port, F3_Pin) ? 0 : 4)
			| (HAL_GPIO_ReadPin(F4_GPIO_Port, F4_Pin) ? 0 : 8);
}

/* 지금 센서 값만 본다. 걸림 확인에 쓴다 */
int full_read(void) {
	return full_now();
}

/* 한 번 감지된 만재는 해제 전까지 유지한다 */
int full_get(void) {
	full |= full_now();
	return full;
}

/* 아직 감지 중인 것만 남기고 나머지는 해제한다 */
int full_clear(void) {
	full = full_now();

	return !full;
}

/* 10ms마다 5번 연속으로 눌린 버튼만 처리한다 */
static int held(GPIO_TypeDef *port, uint16_t pin, uint8_t *count) {
	if (HAL_GPIO_ReadPin(port, pin) != GPIO_PIN_SET) {
		*count = 0;
		return 0;
	}

	if (*count < BUTTON_COUNT + 1)
		(*count)++;

	return *count == BUTTON_COUNT;
}

/* 자동 운전 상태 램프 */
void lamp_ready_start(void) {
	lamp_mode = 'R'; lamp_count = 0;
	HAL_GPIO_WritePin( MOTOR_ON_GPIO_Port, MOTOR_ON_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(STOP_GPIO_Port, STOP_Pin, GPIO_PIN_RESET); HAL_GPIO_WritePin(MOTOR_START_GPIO_Port, MOTOR_START_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(LAMP_RED_GPIO_Port, LAMP_RED_Pin, GPIO_PIN_RESET); HAL_GPIO_WritePin(LAMP_GREEN_GPIO_Port, LAMP_GREEN_Pin, GPIO_PIN_SET);
}

/* 일시정지와 만재: STOP, GREEN 500ms 점멸 */
void lamp_pause(void) {
	if (lamp_mode != 'P') {
		lamp_mode = 'P'; lamp_count = 0;
		HAL_GPIO_WritePin(MOTOR_ON_GPIO_Port, MOTOR_ON_Pin, GPIO_PIN_SET); HAL_GPIO_WritePin(STOP_GPIO_Port, STOP_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(LAMP_GREEN_GPIO_Port, LAMP_GREEN_Pin, GPIO_PIN_RESET);
		return;
	}
	if (++lamp_count < 25) return;
	lamp_count = 0;
	HAL_GPIO_TogglePin(STOP_GPIO_Port, STOP_Pin); HAL_GPIO_TogglePin(LAMP_GREEN_GPIO_Port, LAMP_GREEN_Pin);
}

/* ESTOP과 RFID 미인식: 램프 전체 500ms 점멸 */
void lamp_estop(void) {
	if (lamp_mode != 'E') {
		lamp_mode = 'E'; lamp_count = 0;
		HAL_GPIO_WritePin(MOTOR_ON_GPIO_Port, MOTOR_ON_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(STOP_GPIO_Port, STOP_Pin, GPIO_PIN_SET); HAL_GPIO_WritePin(MOTOR_START_GPIO_Port, MOTOR_START_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(LAMP_RED_GPIO_Port, LAMP_RED_Pin, GPIO_PIN_SET); HAL_GPIO_WritePin(LAMP_GREEN_GPIO_Port, LAMP_GREEN_Pin, GPIO_PIN_SET);
		return;
	}
	if (++lamp_count < 25) return;
	lamp_count = 0;
	HAL_GPIO_TogglePin(STOP_GPIO_Port, STOP_Pin); HAL_GPIO_TogglePin(MOTOR_START_GPIO_Port, MOTOR_START_Pin);
	HAL_GPIO_TogglePin(LAMP_RED_GPIO_Port, LAMP_RED_Pin); HAL_GPIO_TogglePin(LAMP_GREEN_GPIO_Port, LAMP_GREEN_Pin);
}

/* 모터 알람: 램프 전체 250ms 점멸 */
void lamp_alarm(void) {
	if (lamp_mode != 'A') {
		lamp_mode = 'A'; lamp_count = 0;
		HAL_GPIO_WritePin(STOP_GPIO_Port, STOP_Pin, GPIO_PIN_SET); HAL_GPIO_WritePin(MOTOR_START_GPIO_Port, MOTOR_START_Pin, GPIO_PIN_SET);
		HAL_GPIO_WritePin(LAMP_RED_GPIO_Port, LAMP_RED_Pin, GPIO_PIN_SET); HAL_GPIO_WritePin(LAMP_GREEN_GPIO_Port, LAMP_GREEN_Pin, GPIO_PIN_SET);
		return;
	}
	if (++lamp_count < 13) return;
	lamp_count = 0;
	HAL_GPIO_TogglePin(STOP_GPIO_Port, STOP_Pin); HAL_GPIO_TogglePin(MOTOR_START_GPIO_Port, MOTOR_START_Pin);
	HAL_GPIO_TogglePin(LAMP_RED_GPIO_Port, LAMP_RED_Pin); HAL_GPIO_TogglePin(LAMP_GREEN_GPIO_Port, LAMP_GREEN_Pin);
}
/* TCP LAMP 명령을 10ms마다 실행한다 */
static void lamp_tcp(void) {
	int i;
	if (tcp_mode[0] < 2) HAL_GPIO_WritePin(LAMP_RED_GPIO_Port,
			LAMP_RED_Pin, tcp_mode[0] ? GPIO_PIN_SET : GPIO_PIN_RESET);
	if (tcp_mode[1] < 2) HAL_GPIO_WritePin(LAMP_GREEN_GPIO_Port,
			LAMP_GREEN_Pin, tcp_mode[1] ? GPIO_PIN_SET : GPIO_PIN_RESET);
	if (++tcp_count >= 25) {
		tcp_count = 0;
		if (tcp_mode[0] == 2) HAL_GPIO_TogglePin(LAMP_RED_GPIO_Port, LAMP_RED_Pin);
		if (tcp_mode[1] == 2) HAL_GPIO_TogglePin(LAMP_GREEN_GPIO_Port, LAMP_GREEN_Pin);
	}
	for (i = 0; i < 2; i++)
		if (tcp_left[i] > 0 && --tcp_left[i] == 0) tcp_mode[i] = 0;
	if (tcp_auto && !tcp_left[0] && !tcp_left[1]) tcp_on = 0;
}
/* 01LL_1_1_10&L_1_2_00: 적색 점등, 녹색 소등 */
void lamp_cmd(char *s) {
	int c1, id1, m1, t1, c2, id2, m2, t2; char b[64];
	if (sscanf(s, "01LL_%d_%d_%1d%d&L_%d_%d_%1d%d", &c1, &id1, &m1, &t1,
			&c2, &id2, &m2, &t2) != 8 || c1 != 1 || c2 != 1 || id1 < 1
			|| id1 > 2 || id2 < 1 || id2 > 2 || id1 == id2 || m1 < 0
			|| m1 > 2 || m2 < 0 || m2 > 2 || t1 < 0 || t1 > 60 || t2 < 0 || t2 > 60) {
		snprintf(b, sizeof(b), "01%cL_bad_data", NAK); reply(b); return;
	}
	tcp_mode[id1 - 1] = m1; tcp_mode[id2 - 1] = m2;
	tcp_left[id1 - 1] = m1 == 2 ? (t1 ? t1 * 100 : -1) : 0;
	tcp_left[id2 - 1] = m2 == 2 ? (t2 ? t2 * 100 : -1) : 0;
	tcp_auto = (m1 == 2 && t1) || (m2 == 2 && t2);
	tcp_count = 0; tcp_on = 1; lamp_ready_start();
	snprintf(b, sizeof(b), "01%c%s", ACK, s + 2); reply(b);
}
/* ESTOP, 알람, TCP 명령, 일시정지 순서로 램프를 선택한다 */
void lamp_run(char state, int card) {
	if (estop) { tcp_on = 0; lamp_estop(); }
	else if (state == 'A') { tcp_on = 0; lamp_alarm(); }
	else if (tcp_on) lamp_tcp();
	else if (pause && !card) lamp_estop();
	else if (pause) lamp_pause();
	else lamp_ready_start();
}

/* 버튼 및 모터 전원 초기화 */
void button_init(void) {
	run = 0;
	pause = 0;

	estop = HAL_GPIO_ReadPin(ESTOP_btn_GPIO_Port, ESTOP_btn_Pin);
	full = 0;
	full_pause = 0;

	/* MOTOR_ON은 Active High */
	HAL_GPIO_WritePin( MOTOR_ON_GPIO_Port, MOTOR_ON_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(MOTOR_START_GPIO_Port, MOTOR_START_Pin, GPIO_PIN_SET);

	if (estop)
		lamp_estop();
	else
		lamp_ready_start();
}

/* 일시정지. F 만재 M 버튼 S RFID T 걸림.
   F 와 T 는 센서가 비어야 풀린다 */
void pause_on(char why) {
	pause = 1;
	run = 0;
	full_pause = (why == 'F' || why == 'T');
	pause_reason = why;
	lamp_pause();
	pause_msg(why);
}

/* PAUSE를 풀고 작업을 이어간다 */
static void pause_off(void) { pause = 0; run = 1; full_pause = 0; pause_reason = 0; pause_msg(0); lamp_ready_start(); }

/* 만재가 빠졌으면 정지를 푼다 */
int full_release(void) {
	if (!full_clear())
		return 0;
	pause_off();
	return 1;
}

/* 블로킹 동작 중 ESTOP이나 알람이면 현재 명령을 끝낸다 */
int button_stop_requested(void) {
	return estop || alarm_get();
}

/* 버튼 요청 처리 */
void button_run(void) {
	static uint8_t run_count;
	static uint8_t pause_count;
	int estop_now;
	int run_on;
	int pause_on_button;

	full |= full_now();   /* 만재 센서 순간 감지 */
	run_on = held(MOTOR_START_btn_GPIO_Port,
			MOTOR_START_btn_Pin, &run_count);
	pause_on_button = held(STOP_btn_GPIO_Port,
			STOP_btn_Pin, &pause_count);
	estop_now = HAL_GPIO_ReadPin(ESTOP_btn_GPIO_Port, ESTOP_btn_Pin);
	/* ESTOP은 눌리면 바로 적용한다 */
	if (estop_now != estop) {
		estop = estop_now;
		motor_estop(&motorX, estop);
		motor_estop(&motorY, estop);

		if (estop) {
			run = 0;
			pause = 0;
			full_pause = 0;
			pause_reason = 0; pause_msg(0);
			alarm_set(9);
			lamp_estop();
			net_cmd("01S_1");
			print("ESTOP\r\n");
		} else {
			run = 0;
			pause = 0;
			pause_reason = 0; pause_msg(0);
			alarm_set(0);
			lamp_ready_start();
			print("ESTOP CLEAR\r\n");
		}
		return;
	}
	/* ESTOP 중에는 RUN과 PAUSE를 받지 않는다 */
	if (estop) return;
	/* 만재와 RFID PAUSE는 원인이 해제되는 순간 자동으로 푼다 */
	if (pause && pause_reason == 'F' && !full_now()) { full_release(); print("FULL CLEAR\r\n"); }
	if (pause && pause_reason == 'S' && card_ok) { pause_off(); print("RFID CLEAR\r\n"); }
	/* 두 버튼 동시 입력은 PAUSE 우선, 2초 안에 3회면 A_01 */
	if (both_time && --both_time == 0) both_count = 0;
	if (run_on && pause_on_button) {
		if (!both_time) { both_time = 200; both_count = 0; }
		if (++both_count >= 3) {
			both_count = 0; both_time = 0; run = 0; pause = 0;
			pause_reason = 0; pause_msg(0); alarm_set(1); net_cmd("01S_1"); print("A_01\r\n");
			return;
		}
		if (!pause) pause_on('M');
		return;
	}

	/* 정상 운전 중 PAUSE는 50ms 눌린 뒤 적용 */
	if (pause_on_button && !pause) {
		pause_on('M');
		return;
	}
	/* 알람 해제와 ESTOP 해제 뒤 원점복귀는 만재보다 먼저 처리한다 */
	if (run_on && alarm_get()) {
		run = 1; pause = 0; pause_reason = 0; pause_msg(0); net_cmd("01I");
		return;
	}
	if (run_on && !run && !pause) {
		run = 1; lamp_ready_start(); net_cmd("01I");
		return;
	}
	if (full && !pause) {
		pause_on('F');
		return;
	}

	/* RUN도 50ms 이상 눌린 뒤 적용 */
	if (!run_on)
		return;

	/* 만재로 멈춘 것은 센서가 비어야 풀린다 */
	if (full_pause) {
		print(full_release() ? "FULL CLEAR\r\n" : "FULL\r\n");
		return;
	}

	/* 일시정지 해제 */
	if (pause && pause_reason == 'M') {
		full_clear();     /* 시작 버튼에서 만재 해제 */
		pause_off();
		print("START\r\n");
		return;
	}
}
