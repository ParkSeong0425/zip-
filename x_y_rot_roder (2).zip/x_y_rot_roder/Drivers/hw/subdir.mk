################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/hw/TRH033MS_ISO14443A.c \
../Drivers/hw/can.c \
../Drivers/hw/led.c 

OBJS += \
./Drivers/hw/TRH033MS_ISO14443A.o \
./Drivers/hw/can.o \
./Drivers/hw/led.o 

C_DEPS += \
./Drivers/hw/TRH033MS_ISO14443A.d \
./Drivers/hw/can.d \
./Drivers/hw/led.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/hw/%.o Drivers/hw/%.su Drivers/hw/%.cyclo: ../Drivers/hw/%.c Drivers/hw/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m0 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F042x6 -c -I../Core/Inc -I../Drivers/hw -I../Drivers/STM32F0xx_HAL_Driver/Inc -I../Drivers/STM32F0xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F0xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-hw

clean-Drivers-2f-hw:
	-$(RM) ./Drivers/hw/TRH033MS_ISO14443A.cyclo ./Drivers/hw/TRH033MS_ISO14443A.d ./Drivers/hw/TRH033MS_ISO14443A.o ./Drivers/hw/TRH033MS_ISO14443A.su ./Drivers/hw/can.cyclo ./Drivers/hw/can.d ./Drivers/hw/can.o ./Drivers/hw/can.su ./Drivers/hw/led.cyclo ./Drivers/hw/led.d ./Drivers/hw/led.o ./Drivers/hw/led.su

.PHONY: clean-Drivers-2f-hw

