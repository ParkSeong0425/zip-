#ifndef INC_T_MOTOR_H_
#define INC_T_MOTOR_H_

#include "main.h"

/* 기본값은 여기서 변경: ID 2, 시작/기본속도 0, 가감속 500 ms */
#define TM_ID          2
#define TM_PPR         1000
#define TM_START_RPM   0
#define TM_ACC_MS      500
#define TM_DEC_MS      500
#define TM_RPM         0

#define TM_ARRIVE      (1U << 0)
#define TM_RUN         (1U << 2)
#define TM_FAULT       (1U << 3)
#define TM_ENABLE      (1U << 4)

/* 모두 1=성공 0=실패 */
int TM_Init(void);
int TM_Set(uint16_t rpm, uint16_t acc, uint16_t dec);
int TM_Run(uint16_t rpm, int32_t rev);
int TM_Stop(void);
int TM_State(uint16_t *state);
int TM_Pos(int32_t *pulse);

/* FreeRTOS UART 태스크: go <rpm> <rev>, stop, show, read <hex reg> */
void TM_TaskRun(void *arg);

#endif
