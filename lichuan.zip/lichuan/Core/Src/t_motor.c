#include "t_motor.h"
#include "usart.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>
#include <string.h>

/* ===== 레지스터 주소 ===== */

#define ID          TM_ID

#define R_STATE     0x0004
#define R_POS       0x0008
#define R_PPR       0x0023
#define R_START     0x0033
#define R_ACC       0x0034
#define R_DEC       0x0035
#define R_SPEED     0x0036
#define R_TARGET    0x0037
#define R_CTRL      0x004E
#define R_AUX       0x004F

#define GO          0x0001
#define HALT        0x0020
#define ENABLE      0x0500

static TaskHandle_t task;
static uint8_t ch;
static char line[40];
static uint8_t len;

static void print(const char *s) {
	HAL_UART_Transmit(&huart3, (uint8_t*) s, strlen(s), 100);
}

/* ===== RS485 하위 통신 ===== */

static uint16_t crc16(const uint8_t *data, uint16_t len) {
	uint16_t crc = 0xFFFF;

	for (uint16_t i = 0; i < len; i++) {
		crc ^= data[i];
		for (uint8_t j = 0; j < 8; j++)
			crc = (crc & 1U) ? (crc >> 1) ^ 0xA001U : crc >> 1;
	}
	return crc;
}

/* 에러 플래그와 남은 수신 데이터를 비운다 */
static void bus_clear(void) {
	__HAL_UART_CLEAR_OREFLAG(&huart5);
	__HAL_UART_CLEAR_FEFLAG(&huart5);
	__HAL_UART_CLEAR_NEFLAG(&huart5);
	__HAL_UART_CLEAR_PEFLAG(&huart5);

	while (__HAL_UART_GET_FLAG(&huart5, UART_FLAG_RXNE) != RESET) {
		volatile uint8_t d = huart5.Instance->DR;
		(void) d;
	}
}

static int bus_xfer(uint8_t *tx, uint16_t tn, uint8_t *rx, uint16_t rn) {
	HAL_StatusTypeDef r;

	bus_clear();

	/* 송신 방향 */
	HAL_GPIO_WritePin(rs4852_GPIO_Port, rs4852_Pin, GPIO_PIN_SET);
	HAL_Delay(1);

	r = HAL_UART_Transmit(&huart5, tx, tn, 100);

	/* 송신 완료를 기다린 뒤 수신 방향 */
	while (__HAL_UART_GET_FLAG(&huart5, UART_FLAG_TC) == RESET) {
	}
	for (volatile uint32_t i = 0; i < 100; i++) {
	}
	HAL_GPIO_WritePin(rs4852_GPIO_Port, rs4852_Pin, GPIO_PIN_RESET);

	if (r == HAL_OK)
		r = HAL_UART_Receive(&huart5, rx, rn, 500);

	HAL_Delay(20);
	return r == HAL_OK;
}

/* ===== Modbus 읽기/쓰기 ===== */

/* 0x06 단일 레지스터 쓰기. 응답은 요청과 완전히 같아야 한다 */
static int write16(uint16_t reg, uint16_t val) {
	uint8_t tx[8], rx[8];
	uint16_t crc;

	tx[0] = ID;
	tx[1] = 0x06;
	tx[2] = reg >> 8;
	tx[3] = reg;
	tx[4] = val >> 8;
	tx[5] = val;

	crc = crc16(tx, 6);
	tx[6] = crc;
	tx[7] = crc >> 8;

	return bus_xfer(tx, 8, rx, 8) && memcmp(rx, tx, 8) == 0;
}

/* 0x03 읽기. qty=1 또는 2, out[0]=하위워드 out[1]=상위워드 */
static int read_reg(uint16_t reg, uint8_t qty, uint16_t *out) {
	uint8_t tx[8], rx[9];
	uint8_t n = 5 + qty * 2;
	uint16_t crc;

	tx[0] = ID;
	tx[1] = 0x03;
	tx[2] = reg >> 8;
	tx[3] = reg;
	tx[4] = 0;
	tx[5] = qty;

	crc = crc16(tx, 6);
	tx[6] = crc;
	tx[7] = crc >> 8;

	if (!bus_xfer(tx, 8, rx, n))
		return 0;

	crc = crc16(rx, n - 2);

	if (rx[0] != ID || rx[1] != 0x03 || rx[2] != qty * 2
			|| rx[n - 2] != (uint8_t) crc || rx[n - 1] != (uint8_t) (crc >> 8))
		return 0;

	for (uint8_t i = 0; i < qty; i++)
		out[i] = ((uint16_t) rx[3 + i * 2] << 8) | rx[4 + i * 2];
	return 1;
}

/* 0x10 2레지스터(32bit) 쓰기. 하위워드를 먼저 보낸다 */
static int write32(uint16_t reg, int32_t val) {
	uint8_t tx[13], rx[8];
	uint32_t raw = (uint32_t) val;
	uint16_t lo = raw, hi = raw >> 16, crc;

	tx[0] = ID;
	tx[1] = 0x10;
	tx[2] = reg >> 8;
	tx[3] = reg;
	tx[4] = 0;
	tx[5] = 2;
	tx[6] = 4;
	tx[7] = lo >> 8;
	tx[8] = lo;
	tx[9] = hi >> 8;
	tx[10] = hi;

	crc = crc16(tx, 11);
	tx[11] = crc;
	tx[12] = crc >> 8;

	if (!bus_xfer(tx, 13, rx, 8))
		return 0;

	crc = crc16(rx, 6);

	return rx[0] == ID && rx[1] == 0x10 && rx[2] == tx[2] && rx[3] == tx[3]
			&& rx[4] == 0 && rx[5] == 2 && rx[6] == (uint8_t) crc
			&& rx[7] == (uint8_t) (crc >> 8);
}

/* ===== 동작 ===== */

int TM_State(uint16_t *state) {
	return read_reg(R_STATE, 1, state);
}

int TM_Pos(int32_t *pulse) {
	uint16_t w[2];

	if (!read_reg(R_POS, 2, w))
		return 0;
	*pulse = (int32_t) (((uint32_t) w[1] << 16) | w[0]);
	return 1;
}

/* 속도/가감속을 바꾸려면 이 함수를 호출한다 */
int TM_Set(uint16_t rpm, uint16_t acc, uint16_t dec) {
	return write16(R_ACC, acc) && write16(R_DEC, dec) && write16(R_SPEED, rpm);
}

int TM_Stop(void) {
	return write16(R_CTRL, HALT);
}

/* rev 부호가 방향이며 go 500 4 / go 500 -4 처럼 사용한다 */
int TM_Run(uint16_t rpm, int32_t rev) {
	return TM_Set(rpm, TM_ACC_MS, TM_DEC_MS)
			&& write32(R_TARGET, rev * TM_PPR) && write16(R_CTRL, GO);
}

/* 전원 투입 시 위치모드 기본값을 설정한다 */
int TM_Init(void) {
	uint16_t state;

	HAL_GPIO_WritePin(rs4852_GPIO_Port, rs4852_Pin, GPIO_PIN_RESET);

	if (!TM_State(&state))
		return 0;
	if (state & TM_RUN)
		TM_Stop();
	if (state & TM_FAULT)
		return 0;
	if (!(state & TM_ENABLE))
		write16(R_AUX, ENABLE);

	write16(R_PPR, TM_PPR);
	write16(R_START, TM_START_RPM);
	return TM_Set(TM_RPM, TM_ACC_MS, TM_DEC_MS);
}

/* ===== UART3 명령 ===== */

static void command(char *s) {
	unsigned int rpm, reg;
	long rev;
	uint16_t state, val;
	int32_t pos;
	char b[48];
	int ok;

	if (sscanf(s, "go %u %ld", &rpm, &rev) == 2)
		ok = TM_Run(rpm, rev);
	else if (strcmp(s, "stop") == 0)
		ok = TM_Stop();
	else if (strcmp(s, "show") == 0) {
		ok = TM_State(&state) && TM_Pos(&pos);
		if (ok) {
			snprintf(b, sizeof(b), "state=%04X pos=%ld\r\n", state, (long) pos);
			print(b);
			return;
		}
	} else if (sscanf(s, "read %x", &reg) == 1) {
		ok = read_reg(reg, 1, &val);
		if (ok) {
			snprintf(b, sizeof(b), "reg %04X = %04X\r\n", reg, val);
			print(b);
			return;
		}
	} else {
		print("go <rpm> <rev> | stop | show | read <hex reg>\r\n");
		return;
	}
	print(ok ? "OK\r\n" : "ERR\r\n");
}

/* UART3 한 줄이 완성되면 태스크를 깨운다 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	BaseType_t wake = pdFALSE;

	if (huart->Instance != USART3)
		return;

	if (ch == '\r' || ch == '\n') {
		if (len) {
			line[len] = 0;
			vTaskNotifyGiveFromISR(task, &wake);
			portYIELD_FROM_ISR(wake);
			return;
		}
	} else if (len < sizeof(line) - 1)
		line[len++] = ch;

	HAL_UART_Receive_IT(&huart3, &ch, 1);
}

/* freertos.c의 StartUART_Task()가 이 함수를 호출한다 */
void TM_TaskRun(void *arg) {
	(void) arg;

	task = xTaskGetCurrentTaskHandle();
	print(TM_Init() ? "motor ready\r\n" : "motor init ERR\r\n");
	HAL_UART_Receive_IT(&huart3, &ch, 1);

	for (;;) {
		ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
		command(line);
		len = 0;
		HAL_UART_Receive_IT(&huart3, &ch, 1);
	}
}
