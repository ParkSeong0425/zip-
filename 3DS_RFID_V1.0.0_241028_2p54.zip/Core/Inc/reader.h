/**
  ****************************************************************************************************
  * @ File      reader.h
  *
  * @ Project   RSS_3DS_RFID
  * @ Author    KOTECH, MR
  ****************************************************************************************************
  */

#ifndef RFIDR_H_
#define RFIDR_H_


/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"


/* Define ------------------------------------------------------------------*/

typedef enum
{

	NetCMD_Rx_Check				= 'C',		// üũ
} e_RFIDR_Rx_Command;

typedef enum
{
	//NetCMD_Tx_Data				= 'U',		// UID Data

	NetCMD_Tx_ACK					= 0x06,		// ACK
	NetCMD_Tx_NAK					= 0x15,		// NAK
} e_RFIDR_Tx_Command;


/* Variable ------------------------------------------------------------------*/

typedef union
{
	uint8_t  All;

	struct{
		uint8_t New						:1,		// bit[0]
						UnDetect			:1,		// bit[1]
													:6;		// bit[2-7]
	};
} u_Status;


typedef struct
{
	uint32_t		UnDetect;
} s_Timer;
#define UNDETECT_TIMEOUT	500


typedef struct _RFIDR_Info
{
	uint8_t						ID;
	uint8_t						UID[4];

	s_Timer						Count;
	u_Status					Status;

} s_RFIDR_Info;

extern __IO s_RFIDR_Info RFIDR;


/* Macro ------------------------------------------------------------------*/


/* EFP ---------------------------------------------------------*/
extern void RDIDR_Timer(void);
extern void RFIDR_Init(void);
extern void RFIDR_Get_ID(void);
extern void RFIDR_Get_UID(void);
extern void RFIDR_Parser(void);
extern void RFIDR_Process(void);

#endif /* RFIDR_H_ */
