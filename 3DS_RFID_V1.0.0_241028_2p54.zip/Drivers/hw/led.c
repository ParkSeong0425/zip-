/**
  ****************************************************************************************************
  * @ File      led.c
  *
  * @ Project   RSS_MLS
  * @ Author    KOTECH, MR
  ****************************************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "led.h"
#include "main.h"

/* Private variables ---------------------------------------------------------*/
__IO s_LED_Info LED;

// Port, Pin, On, Off, state, on time, toggle time
s_LED_tbl LED_tbl[LED_MAX_CH] =
{
	{LED_STATUS_GPIO_Port,	LED_STATUS_Pin,	GPIO_PIN_RESET, GPIO_PIN_SET, LED_OFF, 0, 0},
	{LED_RFID_GPIO_Port,		LED_RFID_Pin,		GPIO_PIN_RESET, GPIO_PIN_SET, LED_OFF, 0, 0},
};


/* Private function prototypes -----------------------------------------------*/


/* Private functions ---------------------------------------------------------*/

void LED_Init(void)
{
	LED_On(LED_CH_STATUS, 0);
	LED_On(LED_CH_RFID, 0);

	HAL_Delay(1000);

	LED_Off(LED_CH_STATUS);
	LED_Off(LED_CH_RFID);
}

void LED_On(e_LED_Ch ch, uint16_t ms)
{
  if (ch >= LED_MAX_CH) return;
  LED_tbl[ch].OnType = LED_ON;
  LED.Timer[ch].On = LED_tbl[ch].OnTime = ms;
  HAL_GPIO_WritePin(LED_tbl[ch].port, LED_tbl[ch].pin, LED_tbl[ch].on_state);
}

void LED_Off(e_LED_Ch ch)
{
  if (ch >= LED_MAX_CH) return;

  LED_tbl[ch].OnType = LED_OFF;
  HAL_GPIO_WritePin(LED_tbl[ch].port, LED_tbl[ch].pin, LED_tbl[ch].off_state);
}

void LED_Toggle(e_LED_Ch ch, uint16_t ms)
{
  if (ch >= LED_MAX_CH) return;

  LED_tbl[ch].OnType = LED_TOGGLE;
  LED.Timer[ch].Toggle = LED_tbl[ch].ToggleTime = ms;
	HAL_GPIO_TogglePin(LED_tbl[ch].port, LED_tbl[ch].pin);
}

//
void LED_Process(void)
{
	for(e_LED_Ch ch=0; ch<LED_MAX_CH; ch++)
	{
		if(LED.Timer[ch].On > 0) LED.Timer[ch].On--;
		if(LED.Timer[ch].Toggle > 0) LED.Timer[ch].Toggle--;

		if(LED_tbl[ch].OnType == LED_ON)
		{
			if((LED_tbl[ch].OnTime > 0) && (LED.Timer[ch].On == 0))
					LED_Off(ch);
		}
		else if(LED_tbl[ch].OnType == LED_TOGGLE)
		{
			if(LED.Timer[ch].Toggle == 0)
			{
				LED.Timer[ch].Toggle = LED_tbl[ch].ToggleTime;
				HAL_GPIO_TogglePin(LED_tbl[ch].port, LED_tbl[ch].pin);
			}
		}
	}
}


