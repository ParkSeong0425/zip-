/**
  ****************************************************************************************************
  * @ File      TRH033MS_ISO14443A.h
  *
  * @ Project   3DS
  * @ Author    KOTECH
  ****************************************************************************************************
  */

#ifndef _HW_TRH033M_H_
#define _HW_TRH033M_H_

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"

/* Define ------------------------------------------------------------------*/

//#define __debug__TRH033M

#ifdef __debug__TRH033M
	#define trh_printf(fmt,args...) printf( fmt, ## args )
#else
	#define trh_printf(fmt,args...)
#endif


#define TRH_SPI_TIMEOUT		20

#define TIMER0_DELAY(time)  HAL_Delay(time)
#define _delay_ms(time)		 HAL_Delay(time)


enum TRH033M_TIME{
	t_1ms			= 1,
	t_2ms			= 2,
	t_5ms			= 5,
	t_7ms			= 7,
	t_8ms			= 8,
	t_10ms		= 10,
};


//------------------------------------------------------------------------------
//Protocol define
//------------------------------------------------------------------------------
#define PRO_ETC                     0xCC
#define PRO_ISO14443A               0x01
#define PRO_ISO14443B               0x02
#define PRO_ISO15693                0x03
#define PRO_TAGIT                   0x04
#define PRO_ICODE                   0x05
#define PRO_JEWEL                   0x06
#define PRO_INSIDE                  0x07
#define PRO_FELICA                  0x08
#define PRO_CARDDETECT              0x09

//------------------------------------------------------------------------------
//Tag Response define
//------------------------------------------------------------------------------
#define RESPONSE_OK                 0x01
#define RESPONSE_FAIL               0x00
#define COLLISION_DETECT            0x03
#define UID_NOT                     0x09
#define SPEC_NOT                    0xFF

//------------------------------------------------------------------------------
//ISO14443A Command Define
//------------------------------------------------------------------------------
#define CMD_ISO14443A_REG									0xA1
#define CMD_ISO14443A_REQA								0x26
#define CMD_ISO14443A_WUPA								0x52
#define CMD_ISO14443A_AntiCollison_LVEL1	0x93
#define CMD_ISO14443A_AntiCollison_LVEL2	0x95
#define CMD_ISO14443A_AntiCollison_LVEL3	0x97
#define CMD_ISO14443A_SELECT_LVEL1				0x94
#define CMD_ISO14443A_SELECT_LVEL2				0x96
#define CMD_ISO14443A_SELECT_LVEL3				0x98
#define CMD_ISO14443A_HLTA								0x50
#define CMD_ISO14443A											0xF0
#define CMD_ISO14443A_LOOP								0xF1

enum TRH033M_REG{
	//Page 0 register
	REG_PAGE0					= 0x00,	//Selects the register page0
	REG_COMMAND				= 0x01, //Starts and stops the command execution
	REG_FIFODATA			= 0x02, //Input and output of 64 byte FIFO buffer register
	REG_STATUS1				= 0x03, //Shows the Reader chip status
	REG_FIFOLENGTH		= 0x04,	//Number of bytes buffered in the FIFO            
	REG_STATUS2				= 0x05,	//Shows the Reader chip status
	REG_IEN						= 0x06,	//Interrupt enable register
	REG_IRQ						= 0x07,	//Interrupt request register

	//Page 1 register
	REG_PAGE1					= 0x08,	//Selects the page1
	REG_CONTROL				= 0x09,	//Control register
	REG_ERRFLAG				= 0x0A,	//Command error on last activity
	REG_COLLPOS				= 0x0B,	//Location of bit on last collision error
	REG_TIMERVALUE		= 0x0C,	//Actual timer value                             
	REG_CRCRESULTLSB	= 0x0D,	//LSB of CRC result register                     
	REG_CRCRESULTMSB	= 0x0E,	//MSB of CRC result register                     
	REG_BITFRAME			= 0x0F,	//ISO 14443 A bit level transmission control

	//Page 2 register
	REG_PAGE2					= 0x10,	//Selects the page2
	REG_TXCONTROL			= 0x11,	//Control TX1 and TX2
	REG_CWCONDUCTANCE	= 0x12,	//Adjust TX pin output power             
	REG_MODCONDUCTANCE	= 0x13,	//Adjust ASK Modulation index            
	REG_PROTOCOLSET		= 0x14,	//Set TX Encoding, RX Decoding method                 
	REG_MODWIDTH			= 0x15,	//Modify modulation width for 14443A Type
	REG_OFFWIDTH			= 0x16,	//Determine Off width for Tag-It protocol
	REG_BFRAMMING			= 0x17,	//Set framing method for ISO 14443 B

	//Page 3 register
	REG_PAGE3					= 0x18,	//Selects the page3
	REG_RXCONTROL1		= 0x19,	//Receiver control register
	REG_RXTHRESHOLD		= 0x1C,	//Set demodulation standard
	REG_JEWELCTRL			= 0x1D, //Jewel Operation parameter resister
	REG_ETCCTRL				= 0x1E,	//Select decoder input
	REG_TAGITCTRL			= 0x1F, //A Type Threshold Control resister

	//Page 4 register
	REG_PAGE4					= 0x20,	//Select page4
	REG_RXWAIT				= 0x21,	//Set idle time between TX ending and RX beginning
	REG_REDUNDANCY		= 0x22,	//Set data integrity verifying method             
	REG_CRCPRESETLSB	= 0x23,	//LSB of CRC preset register                      
	REG_CRCPRESETMSB	= 0x24,	//MSB of CRC preset register    
	REG_CALOFFSET			= 0x25, //Reciver off state RX Threshold value resister
	REG_TESTOUTSEL		= 0x26,	//TESTOUT pin source selection register   

	//Page 5 register
	REG_PAGE5					= 0x28,	//Selects the page5
	REG_FIFOLEVEL			= 0x29,	//Reference value of FIFO interrupt
	REG_TIMERCLK			= 0x2A,	//Set timer speed
	REG_TCONTROL			= 0x2B,	//Set timer begin and end condition
	REG_TRELOADVALUE	= 0x2C,	//Set timer initial value          
	REG_DETECTCTL			= 0x2D,
	REG_CALIR					= 0x2E,
	REG_DTCASTATR			= 0x2F,
	
	//Page 6 register
	REG_PAGE6					= 0x30,	//Selects the page6
	REG_DETECTLEVEL		= 0x32, //Card Detection Level Control
	REG_DETECTREG			= 0x33, //Card Detection Contorl
	REG_FELPREAMBLE		= 0x34, //
	REG_DETECTIR			= 0x35, //
	REG_DTRELOADH			= 0x36,
	REG_DTRELOADL			= 0x37,
	REG_MCLKONCNT			= 0x39,
	REG_DTCTIMERV			= 0x3B,
	REG_RFONCNT				= 0x3C,
	REG_OPTION				= 0x3F,
};

/* Variable ------------------------------------------------------------------*/


/* EV ------------------------------------------------------------------*/



/* EFP ------------------------------------------------------------------*/
extern void TRH_WRITE(uint8_t addr, uint8_t cmd);
extern uint8_t TRH_READ(uint8_t addr);

extern void TRH033M_Init(void);
extern void TRH033M_Reset(void);
extern void TRH033M_Reset2Active(void);
extern void TRH_FIFO_TEST(void);

extern void Card_Detect(void);
extern void ISO14443A_Reg(void);
extern uint8_t ISO14443A_REQA(void);
//extern uint8_t ISO14443A_REQA(uint8_t Command);
extern uint8_t ISO14443A_AntiSelect(uint8_t sel);
extern uint8_t ISO14443A_RunFunctions(void);

extern uint8_t ISO14443A_AntiCollision(uint8_t Command);
extern uint8_t ISO14443A_SELECT(uint8_t Command);
extern void ISO14443A_HALT(uint8_t Command);
extern void ISO14443A_Read(void);

#endif			/*_HW_TRH033M_H_*/
