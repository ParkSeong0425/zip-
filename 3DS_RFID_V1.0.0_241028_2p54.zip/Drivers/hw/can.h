/**
  ****************************************************************************************************
  * @ File      CAN.h
  *
  * @ Project   3DS
  * @ Author    KOTECH, MR
  ****************************************************************************************************
  */

#ifndef _HW_CAN_H_
#define _HW_CAN_H_

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"

/* Define ------------------------------------------------------------------*/

//
//#define __CAN_DEGUG_PRINT


#define CAN_RFID_ID_BASE		200

// CAN state
typedef enum
{
	CAN_STATE_None	 					= 0,	//
	CAN_STATE_Tx_Error				= 1,	//
	CAN_STATE_Rx_Wait		 			= 2,	//
	CAN_STATE_Rx_Complete			= 3,	//
	CAN_STATE_Receive					= 8,	//
} e_CAN_STATE;

//
typedef struct
{
	e_CAN_STATE		State;
	uint8_t				StdId;
	uint8_t				RxIDE;
	uint8_t				RxDLC;
	uint8_t				RxData[8];
} s_CAN_info;

extern s_CAN_info	CAN1_Info;


/* EV ------------------------------------------------------------------*/
extern CAN_HandleTypeDef hcan;



/* EFP ------------------------------------------------------------------*/
extern void CAN_Init(void);
extern void CAN_Test_Tx(void);
extern void CAN1_Tx_Data(uint32_t id, uint8_t *msg, uint8_t len);
extern void CAN2_Tx_Data(uint32_t id, uint8_t *msg, uint8_t len);

#endif
