/**
  ****************************************************************************************************
  * @ File      CAN.c
  *
  * @ Project   3DS
  * @ Author    KOTECH, MR
  ****************************************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include "can.h"
#include "main.h"
#include "reader.h"

/* Private variables ---------------------------------------------------------*/

CAN_TxHeaderTypeDef   TxHeader;
uint8_t               TxData[8];
uint32_t              TxMailbox;

CAN_FilterTypeDef  		sFilterConfig;   // ���� ���� ����ü ����
CAN_RxHeaderTypeDef   RxHeader;
uint8_t               RxBuff[8];

s_CAN_info	CAN1_Info;

/* Private function prototypes -----------------------------------------------*/


/* Private functions ---------------------------------------------------------*/

void CAN_Init(void)
{
	/* Configure Transmission process */
	TxHeader.StdId = 0xFF;	                // Standard Identifier, 0 ~ 0x7FF
	TxHeader.ExtId = 0x01;                  // Extended Identifier, 0 ~ 0x1FFFFFFF
	TxHeader.RTR = CAN_RTR_DATA;            // �����ϴ� �޼����� ������ Ÿ��, DATA or REMOTE
	TxHeader.IDE = CAN_ID_STD;              // �����ϴ� �޼����� �ĺ��� Ÿ��, STD or EXT
	TxHeader.DLC = 8;                       // �۽� ������ ����, 0 ~ 8 byte
	TxHeader.TransmitGlobalTime = DISABLE;  // ������ ���� ���۵� �� timestamp counter ���� capture.

	/* CAN Filter config' */
	sFilterConfig.FilterBank = 0;
	sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
	sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
	sFilterConfig.FilterIdHigh = 0x0000;
	sFilterConfig.FilterIdLow = 0x0000;
	sFilterConfig.FilterMaskIdHigh = 0x0000;              // 0x00000000 = all ID receive
	sFilterConfig.FilterMaskIdLow = 0x0000;
	sFilterConfig.FilterFIFOAssignment = CAN_RX_FIFO0;
	sFilterConfig.FilterActivation = ENABLE;
	sFilterConfig.SlaveStartFilterBank = 14;              // CAN2�� FilterBank���� ��ġ, CAN2�� ����Ѵٸ� FilterBank�� SlaveStartFilterBank���� ũ�� �����ؾ� ��.


	if (HAL_CAN_ConfigFilter(&hcan, &sFilterConfig) != HAL_OK)
	{
	/* Filter configuration Error */
	Error_Handler();
	}

	/* Can Start */
	if (HAL_CAN_Start(&hcan) != HAL_OK)
	{
	/* Start Error */
	Error_Handler();
	}

	/* Activate CAN RX notification */
	if (HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING) != HAL_OK)
	{
	/* Notification Error */
	Error_Handler();
	}
}

void CAN_Test_Tx(void)
{
	TxData[0] = 1;
	TxData[1] = 2;
	TxData[2] = 3;
	TxData[3] = 4;
	TxData[4] = 5;
	TxData[5] = 6;
	TxData[6] = 7;
	TxData[7] = 8;

	/* Start the Transmission process */
	do {
		TxMailbox = HAL_CAN_GetTxMailboxesFreeLevel(&hcan);
	} while(TxMailbox == 0);

	if (HAL_CAN_AddTxMessage(&hcan, &TxHeader, TxData, &TxMailbox) != HAL_OK)
	{
	  printf("Can Send Fail\r\n");
	  //Error_Handler();
		return;
	}
	//printf("Can Send Success\r\n");
}

void CAN1_Tx_Data(uint32_t id, uint8_t *msg, uint8_t len)
{
	memset(CAN1_Info.RxData, 0, 8);

	TxHeader.StdId = id;						// Standard Identifier, 0 ~ 0x7FF
	TxHeader.RTR = CAN_RTR_DATA;    // DATA or REMOTE
	TxHeader.DLC = len;							// length, 0 ~ 8 byte
	memcpy(TxData, msg, len);

	do {
		TxMailbox = HAL_CAN_GetTxMailboxesFreeLevel(&hcan);
	} while(TxMailbox == 0);

	if (HAL_CAN_AddTxMessage(&hcan, &TxHeader, TxData, &TxMailbox) != HAL_OK)
	{
		CAN1_Info.State = CAN_STATE_Tx_Error;
		printf("Can1 Send Fail..\r\n");
	  //Error_Handler();
		return;
	}
}

/* Interrupt Callback ---------------------------------------------------------*/
// CAN ���� ���ͷ�Ʈ �ݹ�
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *CanHandle)
{
	//printf("%s\r\n", __FUNCTION__);
	/* Get RX message */
	if (HAL_CAN_GetRxMessage(CanHandle, CAN_RX_FIFO0, &RxHeader, RxBuff) != HAL_OK)
	{
		/* Reception Error */
	  //Error_Handler();
		return;
	}

	//if(CanHandle->Instance == CAN)
	{
		//if((uint8_t)RxHeader.StdId != RFIDR.ID) return;
		if((uint8_t)RxHeader.StdId != RFIDR.ID+CAN_RFID_ID_BASE) return;
		CAN1_Info.State = CAN_STATE_Receive;
		CAN1_Info.StdId = (uint8_t)RxHeader.StdId;
		//CAN1_Info.RxIDE = (uint8_t)RxHeader.IDE;
		CAN1_Info.RxDLC = (uint8_t)RxHeader.DLC;
		memcpy(CAN1_Info.RxData, RxBuff, CAN1_Info.RxDLC);

		RFIDR_Parser();
	}

#ifdef __CAN_DEGUG_PRINT
	printf("StdID: %04lx, IDE: %ld, DLC: %ld\r\n", RxHeader.StdId, RxHeader.IDE, RxHeader.DLC);
	printf("Data: %d %d %d %d %d %d %d %d\r\n", RxBuff[0], RxBuff[1], RxBuff[2], RxBuff[3], RxBuff[4], RxBuff[5], RxBuff[6], RxBuff[7]);
	printf("Data: %02x %02x %02x %02x %02x %02x %02x %02x \r\n", RxBuff[0], RxBuff[1], RxBuff[2], RxBuff[3], RxBuff[4], RxBuff[5], RxBuff[6], RxBuff[7]);
#endif
}

// CAN Error �ݹ�
void HAL_CAN_ErrorCallback(CAN_HandleTypeDef *hcan)
{
	printf("%s\r\n", __FUNCTION__);
}



