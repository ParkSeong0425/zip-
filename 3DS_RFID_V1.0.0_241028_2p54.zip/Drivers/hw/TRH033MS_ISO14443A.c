
/**
  ****************************************************************************************************
  * @ File      TRH033MS_ISO14443A.c
  *
  * @ Project   3DS
  * @ Author    KOTECH
  ****************************************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include "main.h"
#include "reader.h"
#include "TRH033MS_ISO14443A.h"
#include "led.h"

/* Private variables ---------------------------------------------------------*/
extern SPI_HandleTypeDef hspi1;


uint8_t TRH_LEN;
uint8_t TRH_ERR;
uint8_t ATQA[5];
uint8_t ACID[5];
uint8_t ACID1[5];
uint8_t ACID2[5];
uint8_t ACID3[5];
uint8_t UID[8];
uint8_t SAK;

uint8_t RxPRO;
uint8_t RxCom;



/* Private function prototypes -----------------------------------------------*/


/* Private functions ---------------------------------------------------------*/

void TRH_WRITE(uint8_t addr, uint8_t cmd)
{
	uint8_t data[2];
	data[0] = (addr << 1) & 0x7F;
	data[1] = cmd;
	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_RESET);
	HAL_SPI_TransmitReceive(&hspi1, data, data, 2, TRH_SPI_TIMEOUT);
	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_SET);

}

uint8_t TRH_READ(uint8_t addr)
{
	uint8_t data[2];
	data[0] = (addr << 1) | 0x80;
	data[1] = 0x00;
	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_RESET);
	HAL_SPI_TransmitReceive(&hspi1, data, data, 2, TRH_SPI_TIMEOUT);
	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_SET);
	//trh_printf("SPI read  : %02X %02X\r\n", addr, data[1]);
	return data[1];
}

void TRH033M_Init(void)
{
	TRH033M_Reset();
	TRH_WRITE(REG_COMMAND, 0x00);	//Starts and stops the command execution
	trh_printf("%s\r\n", __FUNCTION__);
}

void TRH033M_Reset(void)
{
	HAL_GPIO_WritePin(TRH033M_RESET_GPIO_Port, TRH033M_RESET_Pin, GPIO_PIN_SET);
	TIMER0_DELAY(t_1ms);
	HAL_GPIO_WritePin(TRH033M_RESET_GPIO_Port, TRH033M_RESET_Pin, GPIO_PIN_RESET);
	TIMER0_DELAY(t_1ms);
}


void TRH033M_Reset2Active(void)
{
	TRH033M_Reset();
	TRH_WRITE(REG_COMMAND, 0x00);
	//TRH_WRITE(REG_OPTION, 0xA5);
	TRH_WRITE(REG_CALIR, 0x00);
}


void TRH_FIFO_TEST(void)
{
	uint8_t i;
	TRH_WRITE(0x09, 0x01);
	for(i=0;i<64;i++) TRH_WRITE(0x02, i);

	trh_printf("FIFO DATA TEST = ");
	for(i=0;i<64;i++)
		trh_printf("%02X ", TRH_READ(0x02));
	trh_printf("\n");
}

void Card_Detect(void)
{

	TRH033M_Reset();
	TRH_WRITE(REG_COMMAND, 0x00);

	TRH_WRITE(REG_TXCONTROL, 0x0A); // RF Off
    TRH_WRITE(REG_CWCONDUCTANCE, 0x01); // CWConductance
	TRH_WRITE(REG_MODCONDUCTANCE, 0x05);
	TRH_WRITE(REG_RXCONTROL1, 0x80); // rxcontrol1 0111_0011
	TRH_WRITE(REG_IRQ, 0x7F); // Clear Interrupt IRQ 

	TRH_WRITE(REG_TESTOUTSEL, 0x05);  // CdOut

	TRH_WRITE(REG_TCONTROL, 0x00);
	TRH_WRITE(REG_DETECTCTL, 0x02);
	TRH_WRITE(REG_TRELOADVALUE, 0x0A);
	TRH_WRITE(REG_MCLKONCNT, 0x0A);  //  
	TRH_WRITE(REG_RFONCNT, 0x02);  //  

	TRH_WRITE(REG_DTRELOADH, 0xC0); //  
	TRH_WRITE(REG_DTRELOADL, 0xC0); //  

	TRH_WRITE(REG_CALOFFSET, 0xD0);  // OFFSET
	
	TRH_WRITE(REG_DETECTREG, 0x44);  // iclk enable

	TRH_WRITE(REG_IEN, 0xC0);  // Detection Interrupt Enable           
	
	TRH_WRITE(REG_DETECTREG, 0x44);  // 

	TRH_WRITE(REG_CALIR, 0x27);  // CARD Calibration
	TIMER0_DELAY(t_5ms);
	TRH_WRITE(REG_CALIR, 0x00);  // CARD Calibration
	
	
	TRH_WRITE(REG_IRQ, 0x7F);
	TRH_WRITE(REG_IEN, 0xC0);  
	TRH_WRITE(REG_DETECTIR, 0x57);  // DETECTIR Instruction
	TIMER0_DELAY(t_1ms);
}

void ISO14443A_Reg(void)
{
  //############################################################################
  TRH_WRITE(0x11, 0x5B);	// REG_TXCONTROL		= 0x11,	//Control TX1 and TX2
  TRH_WRITE(0x12, 0x3F);	// REG_CWCONDUCTANCE	= 0x12,	//Adjust TX pin output power   
  TRH_WRITE(0x19, 0x01); /* GAIN */	// REG_RXCONTROL1		= 0x19,	//Receiver control register
  TRH_WRITE(0x1C, 0xA5);	// REG_RXTHRESHOLD		= 0x1C,	//Set demodulation standard
  //############################################################################
  TRH_WRITE(0x14, 0x01);	// REG_PROTOCOLSET		= 0x14,	//Set TX Encoding, RX Decoding method
  //######################################################
  TRH_WRITE(0x15, 0x10);	// REG_MODWIDTH			= 0x15,	//Modify modulation width for 14443A Type
  //############################################
  TRH_WRITE(0x1E, 0x01);	// REG_ETCCTRL			= 0x1E,	//Select decoder input
  TRH_WRITE(0x21, 0x06);	// REG_RXWAIT			= 0x21,	//Set idle time between TX ending and RX beginning
  TRH_WRITE(0x22, 0x03);	// REG_REDUNDANCY		= 0x22,	//Set data integrity verifying method
  //############################################################################
  _delay_ms(5);
}
/*
void ISO14443A_Reg(void)
{
	//Analog Setting
	TRH_WRITE(REG_TXCONTROL, 0x5B);
	TRH_WRITE(REG_CWCONDUCTANCE, 0x3F);
	TRH_WRITE(REG_RXCONTROL1, 0x01);
	TRH_WRITE(REG_RXTHRESHOLD, 0xA5);
	//Digital Setting
	TRH_WRITE(REG_PROTOCOLSET, 0x01);
	TRH_WRITE(REG_ETCCTRL, 0x01);
	TRH_WRITE(REG_RXWAIT, 0x06);
	TRH_WRITE(REG_DETECTLEVEL, 0x80);
	TRH_WRITE(REG_TESTOUTSEL, 0x02);
	if((RxPRO == PRO_ISO14443A)  &&  (RxCom == CMD_ISO14443A_Reg)) trh_printf("ISO14443A Register Setting\n");
	TIMER0_DELAY(t_1ms);
}
*/
#if 1
uint8_t ISO14443A_REQA(void)
{
  TRH_WRITE(0x0F, 0x07);	// REG_BITFRAME			= 0x0F,	//ISO 14443 A bit level transmission control
  TRH_WRITE(0x22, 0x03);	// REG_REDUNDANCY		= 0x22,	//Set data integrity verifying method
  TRH_WRITE(0x09, 0x01);	// REG_CONTROL			= 0x09,	//Control register
  TRH_WRITE(0x02, 0x26);	// REG_FIFODATA			= 0x02, //Input and output of 64 byte FIFO buffer register
  
  TRH_WRITE(0x01, 0x14);	// REG_COMMAND			= 0x01, //Starts and stops the command execution

  _delay_ms(2);

  TRH_LEN = TRH_READ(0x04);	// REG_FIFOLENGTH		= 0x04,	//Number of bytes buffered in the FIFO
  TRH_ERR = TRH_READ(0x0A);	// REG_ERRFLAG			= 0x0A,	//Command error on last activity
  TRH_WRITE(0x01, 0x00);	// REG_COMMAND			= 0x01, //Starts and stops the command execution
  TRH_WRITE(0x2E, 0x00);	// REG_CALIR			= 0x2E,

  if((TRH_LEN == 2)&&!(TRH_ERR&0x02))
  {
    ATQA[0] = TRH_READ(0x02);	// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
    ATQA[1] = TRH_READ(0x02);	// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
    return 1;
  }
  else return 0;
}
#else
uint8_t ISO14443A_REQA(uint8_t Command)
{
	uint8_t LEN, ERR, RxPRO, RxCom;

	TRH_WRITE(REG_BITFRAME, 0x07);	
	TRH_WRITE(REG_REDUNDANCY, 0x03);
	TRH_WRITE(REG_CONTROL, 0x01);
	TRH_WRITE(REG_FIFODATA, Command);
	TRH_WRITE(REG_COMMAND, 0x14);

	TIMER0_DELAY(t_1ms);

	LEN = TRH_READ(REG_FIFOLENGTH);
	ERR = TRH_READ(REG_ERRFLAG);
	TRH_WRITE(REG_COMMAND, 0x00);
	TRH_WRITE(REG_CALIR, 0x00);
	
	if((LEN == 2) && !(ERR&0x02))
	{
		ATQA[0] = TRH_READ(REG_FIFODATA);
		ATQA[1] = TRH_READ(REG_FIFODATA);
		if(ATQA[1] == 0x0C){
			return RESPONSE_FAIL;
		}
		else{
			if((RxPRO == PRO_ISO14443A)  &&  (RxCom == CMD_ISO14443A_REQA)){
				trh_printf("ISO14443A ATQA = %x %x \n", ATQA[0], ATQA[1]);
			}
			if((RxPRO == PRO_ISO14443A)  &&  (RxCom == CMD_ISO14443A_WUPA)){
				trh_printf("ISO14443A ATQA = %x %x \n", ATQA[0], ATQA[1]);
			}
			return RESPONSE_OK;
		}
	}
	else{
		if((RxPRO == PRO_ISO14443A)  &&  (RxCom == CMD_ISO14443A_REQA)) trh_printf("NO ATQA Response!!\n");
		if((RxPRO == PRO_ISO14443A)  &&  (RxCom == CMD_ISO14443A_WUPA)) trh_printf("NO ATQA Response!!\n");
		return RESPONSE_FAIL;
	}
}
#endif

uint8_t ISO14443A_AntiSelect(uint8_t sel)	// // CMD_ISO14443A_AntiCollison_LVEL1		= 0x93
{
	uint8_t i;
	uint8_t NVB, bytecnt, bitcnt, collpos, collcnt, collision;
	uint8_t tmp;

  for(i=0;i<5;i++) UID[i] = 0;
  NVB = 0x20;
  bytecnt = 0;
  bitcnt = 0;
  collision = 1;
  collcnt = 0;

  TRH_WRITE(0x0F, 0x00);	// REG_BITFRAME			= 0x0F,	//ISO 14443 A bit level transmission control
  TRH_WRITE(0x22, 0x03);	// REG_REDUNDANCY		= 0x22,	//Set data integrity verifying method
  TRH_WRITE(0x1E, 0x21);	// REG_ETCCTRL			= 0x1E,	//Select decoder input
  while(collision){
    TRH_WRITE(0x09, 0x01);	// REG_CONTROL			= 0x09,	//Control register
    TRH_WRITE(0x02, sel);	// REG_FIFODATA			= 0x02, //Input and output of 64 byte FIFO buffer register
    TRH_WRITE(0x02, NVB);	// REG_FIFODATA			= 0x02, //Input and output of 64 byte FIFO buffer register
    for(i=0;i<bytecnt;i++) TRH_WRITE(0x02, UID[i]);	// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
    if(bitcnt != 0){
      TRH_WRITE(0x02, UID[bytecnt]);				// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
      TRH_WRITE(0x0F, (bitcnt<<4) | bitcnt);		// REG_BITFRAME		= 0x0F,	//ISO 14443 A bit level transmission control
    }
    
    TRH_WRITE(0x01, 0x14);	// REG_COMMAND			= 0x01, //Starts and stops the command execution
    
    _delay_ms(3);
    
    TRH_LEN = TRH_READ(0x04);	// REG_FIFOLENGTH		= 0x04,	//Number of bytes buffered in the FIFO
    TRH_ERR = TRH_READ(0x0A);	// REG_ERRFLAG			= 0x0A,	//Command error on last activity
    TRH_WRITE(0x01, 0x00);		// REG_COMMAND			= 0x01, //Starts and stops the command execution
    TRH_WRITE(0x2E, 0x00);		// REG_CALIR			= 0x2E,
    if(TRH_ERR&0x01){
      for(i=bytecnt;i<5;i++) UID[i] |= TRH_READ(0x02);	// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
      collpos = TRH_READ(0x0B);							// REG_COLLPOS		= 0x0B,	//Location of bit on last collision error
      bytecnt += collpos/8;
      bitcnt += collpos%8;
      if(bitcnt >= 8){
        bytecnt++;
        bitcnt -= 8;
      }
      NVB = 0x20 + ((bytecnt<<4)|bitcnt);
      collcnt++;
      if(collcnt >= 3){
        collision = 0;
        TRH_WRITE(0x1E, 0x01);	// REG_ETCCTRL		= 0x1E,	//Select decoder input
        TRH_WRITE(0x0F, 0x00);	// REG_BITFRAME		= 0x0F,	//ISO 14443 A bit level transmission control
        return 0;
      }
    }
    else{
      for(i=bytecnt;i<5;i++) UID[i] |= TRH_READ(0x02);	// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
      collision = 0;
    }
  }
  //####################################################
  TRH_WRITE(0x1E, 0x01);	// REG_ETCCTRL		= 0x1E,	//Select decoder input
  TRH_WRITE(0x0F, 0x00);	// REG_BITFRAME		= 0x0F,	//ISO 14443 A bit level transmission control
  TRH_WRITE(0x22, 0x0F);	// REG_REDUNDANCY	= 0x22,	//Set data integrity verifying method
  //####################################################
  TRH_WRITE(0x09, 0x01);	// REG_CONTROL		= 0x09,	//Control register
  TRH_WRITE(0x02, sel);		// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
  TRH_WRITE(0x02, 0x70);	// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
  for(i=0;i<5;i++) TRH_WRITE(0x02, UID[i]);	// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
  //####################################################
  TRH_WRITE(0x01, 0x14);	// REG_COMMAND			= 0x01, //Starts and stops the command execution
  //####################################################
  _delay_ms(3);
  //####################################################
  TRH_LEN = TRH_READ(0x04);	// REG_FIFOLENGTH		= 0x04,	//Number of bytes buffered in the FIFO
  TRH_ERR = TRH_READ(0x0A);	// REG_ERRFLAG			= 0x0A,	//Command error on last activity
  TRH_WRITE(0x01, 0x00);	// REG_COMMAND			= 0x01, //Starts and stops the command execution
  TRH_WRITE(0x2E, 0x00);	// REG_CALIR			= 0x2E,

  if((TRH_LEN==1)&&!(TRH_ERR&0x08)&&!(TRH_ERR&0x02)){
    SAK = TRH_READ(0x02);	// REG_FIFODATA		= 0x02, //Input and output of 64 byte FIFO buffer register
    tmp = SAK;
    tmp &= 0x64;
    if(tmp == 0x00) return 1;      //not ISO14443A part 4
    else if(tmp == 0x04) return 2; //UID not complete
    else if(tmp == 0x24) return 2; //UID not complete
    else if(tmp == 0x20) return 3; //ISO14443A part 4
    else if(tmp == 0x40) return 5; //Smart Phone
    else if(tmp == 0x60) return 5; //Smart Phone
    else return 0;
  }
  else return 0;
}

uint8_t ISO14443A_RunFunctions(void)
{
	uint8_t i;
	uint8_t tmp;
	uint8_t buff[16];
  
  ISO14443A_Reg();
  tmp = ISO14443A_REQA();
  if(tmp == 0)
  {
  	trh_printf("\n\r REQA fail");
  	return 0;
  }

  tmp = ISO14443A_AntiSelect(0x93);	// CMD_ISO14443A_AntiCollison_LVEL1
  if(tmp == 1)
  {
  	//Mifare classic card
  	trh_printf("\n\r Mifare UID = %x, %x, %x, %x", UID[0], UID[1], UID[2], UID[3]);
		return 1;
  }
	trh_printf("\n\r AntiSelect fail");
  return 0;
}


uint8_t ISO14443A_AntiCollision(uint8_t Command)
{
	uint8_t i, Collision = 1, NVB = 0x20, byteCount = 0, BitCount = 0, loop_cnt= 0, CollPos;
	uint8_t ERR, LEN;

    for(i=0;i<5;i++) ACID[i] = 0x00;


    TRH_WRITE(REG_BITFRAME, 0x00);
    TRH_WRITE(REG_REDUNDANCY, 0x03);
    TRH_WRITE(REG_ETCCTRL, 0x21);

    while(Collision)
    {
        TRH_WRITE(REG_CONTROL, 0x01);
        TRH_WRITE(REG_FIFODATA, Command);
        TRH_WRITE(REG_FIFODATA, NVB);

        for(i=0;i<byteCount;i++) TRH_WRITE(REG_FIFODATA, ACID[i]);

        if(BitCount != 0)
        {
            TRH_WRITE(REG_FIFODATA, ACID[byteCount]);
            TRH_WRITE(REG_BITFRAME, (BitCount<<4) | BitCount);
        }

        TRH_WRITE(REG_COMMAND, 0x14);

        TIMER0_DELAY(t_2ms);

        LEN = TRH_READ(REG_FIFOLENGTH);
        ERR = TRH_READ(REG_ERRFLAG);
        TRH_WRITE(REG_COMMAND, 0x00);
        TRH_WRITE(REG_CALIR, 0x00);

        if(ERR & 0x01){
            for(i = byteCount; i<5; i++) ACID[i] |= TRH_READ(REG_FIFODATA);

            CollPos = TRH_READ(REG_COLLPOS);

            byteCount += CollPos/8;
            BitCount += CollPos%8;
            if(BitCount>=8){
                byteCount++;
                BitCount -= 8;
            }

            NVB = 0x20 + ((byteCount<<4) + BitCount);

            if(loop_cnt == 10){
                TRH_WRITE(REG_BITFRAME, 0x00);
                TRH_WRITE(REG_ETCCTRL, 0x01);
                return RESPONSE_FAIL;
            }
            loop_cnt++;
        }
        else{
            if(ERR&0x02){
                TRH_WRITE(REG_BITFRAME, 0x00);
                TRH_WRITE(REG_ETCCTRL, 0x01);
                return RESPONSE_FAIL;
            }
            else{
                Collision = 0;
                for(i=byteCount;i<5;i++) ACID[i] |= TRH_READ(REG_FIFODATA);
                TRH_WRITE(REG_BITFRAME, 0x00);
                TRH_WRITE(REG_ETCCTRL, 0x01);
                if(RxPRO == PRO_ISO14443A){
                    if(RxCom == CMD_ISO14443A_AntiCollison_LVEL1){
                    	trh_printf("ISO14443A Cascade level1 Anticollision = ");
                    	trh_printf("%x, %x, %x, %x, %x", ACID[0], ACID[1], ACID[2], ACID[3], ACID[4]);
                      trh_printf("\n");
                    }
                    else if(RxCom == CMD_ISO14443A_AntiCollison_LVEL2){
                        trh_printf("ISO14443A Cascade level2 Anticollision = ");
                      	trh_printf("%x, %x, %x, %x, %x", ACID[0], ACID[1], ACID[2], ACID[3], ACID[4]);
                        trh_printf("\n");
                    }
                    else if(RxCom == CMD_ISO14443A_AntiCollison_LVEL3){
                        trh_printf("ISO14443A Cascade level3 Anticollision = ");
                      	trh_printf("%x, %x, %x, %x, %x", ACID[0], ACID[1], ACID[2], ACID[3], ACID[4]);
                        trh_printf("\n");
                    }
                }
                return RESPONSE_OK;
            }
        }
    }
    return RESPONSE_FAIL;
}

uint8_t ISO14443A_SELECT(uint8_t Command)
{
	uint8_t i, NVB = 0x70;
	uint8_t ERR, LEN;

    TRH_WRITE(REG_REDUNDANCY, 0x0F);
    TRH_WRITE(REG_CONTROL, 0x01);
    TRH_WRITE(REG_FIFODATA, Command);
    TRH_WRITE(REG_FIFODATA, NVB);
    for(i = 0; i<5; i++) TRH_WRITE(REG_FIFODATA, ACID[i]);

    TRH_WRITE(REG_COMMAND, 0x14);

    TIMER0_DELAY(t_2ms);

    LEN = TRH_READ(REG_FIFOLENGTH);
    ERR = TRH_READ(REG_ERRFLAG);
    TRH_WRITE(REG_COMMAND, 0x00);
    TRH_WRITE(REG_CALIR, 0x00);

    if((LEN == 1) && !(ERR&0x08) && !(ERR&0x02)){
        SAK = TRH_READ(REG_FIFODATA);
        if(SAK&0x04){
            if(RxPRO == PRO_ISO14443A){
                if(RxCom == CMD_ISO14443A_SELECT_LVEL1){
                    trh_printf("ISO14443A Cascade level1 UID Not Complete!!\n");
                    trh_printf("ISO14443A SAK(Select Acknowledge) = %x \n", SAK);
                }
                else if(RxCom == CMD_ISO14443A_SELECT_LVEL2){
                    trh_printf("ISO14443A Cascade level2 UID Not Complete!!\n");
                    trh_printf("ISO14443A SAK(Select Acknowledge) =  %x \n", SAK);
                }
                else if(RxCom == CMD_ISO14443A_SELECT_LVEL3){
                    trh_printf("Please, Check of Software, Hardware, ISO14443A!!\n");
                    trh_printf("ISO14443A SAK(Select Acknowledge) = %x \n", SAK);
                }
            }
            return UID_NOT;
        }
        else{
            if(RxPRO == PRO_ISO14443A){
                if(RxCom == CMD_ISO14443A_SELECT_LVEL1){
                    trh_printf("ISO14443A Cascade level1 UID Complete!!\n");
                    trh_printf("ISO14443A SAK(Select Acknowledge) = %x \n", SAK);
                }
                else if(RxCom == CMD_ISO14443A_SELECT_LVEL2){
                    trh_printf("ISO14443A Cascade level2 UID Complete!!\n");
                    trh_printf("ISO14443A SAK(Select Acknowledge) = %x \n", SAK);
                }
                else if(RxCom == CMD_ISO14443A_SELECT_LVEL3){
                    trh_printf("ISO14443A Cascade level3 UID Complete!!\n");
                    trh_printf("ISO14443A SAK(Select Acknowledge) = %x \n", SAK);
                }
            }
            return RESPONSE_OK;
        }
    }
    else{
        if(RxPRO == PRO_ISO14443A){
            if(RxCom == CMD_ISO14443A_SELECT_LVEL1) trh_printf("NO ISO14443A Cascade level1 SELECT Response!!\n");
            else if(RxCom == CMD_ISO14443A_SELECT_LVEL2) trh_printf("NO ISO14443A Cascade level2 SELECT Response!!\n");
            else if(RxCom == CMD_ISO14443A_SELECT_LVEL3) trh_printf("NO ISO14443A Cascade level3 SELECT Response!!\n");
        }
        return RESPONSE_FAIL;
    }
}


void ISO14443A_HALT(uint8_t Command)
{
	TRH_WRITE(REG_REDUNDANCY, 0x0F);
	TRH_WRITE(REG_CONTROL, 0x01);
	TRH_WRITE(REG_FIFODATA, Command);
	TRH_WRITE(REG_FIFODATA, 0x00);

	TRH_WRITE(REG_COMMAND, 0x1A);

	TIMER0_DELAY(t_1ms);
	if((RxPRO == PRO_ISO14443A) && (RxCom == CMD_ISO14443A_HLTA))
		trh_printf("ISO14443A HLTA Process End!!\n");
}


void ISO14443A_Read(void)
{
	uint8_t detect = 1;
	uint8_t Cont, i;

	ISO14443A_Reg();
	while(detect)
	{
		//if(ISO14443A_REQA(CMD_ISO14443A_REQA) == RESPONSE_OK)
		if(ISO14443A_REQA() == RESPONSE_OK)
		{
			if(ISO14443A_AntiCollision(CMD_ISO14443A_AntiCollison_LVEL1) == RESPONSE_OK)
			{
				Cont = ISO14443A_SELECT(CMD_ISO14443A_AntiCollison_LVEL1);
				if(Cont == UID_NOT)
				{
					for(i=0; i<5; i++) ACID1[i] = ACID[i];
						trh_printf("Cascade level1 UID = %x, %x, %x, %x, %x \n", ACID1[0], ACID1[1], ACID1[2], ACID1[3], ACID1[4]);

					if(ISO14443A_AntiCollision(CMD_ISO14443A_AntiCollison_LVEL2) == RESPONSE_OK)
					{
						Cont = ISO14443A_SELECT(CMD_ISO14443A_AntiCollison_LVEL2);
						if(Cont == UID_NOT)
						{
							for(i=0; i<5; i++) ACID2[i] = ACID[i];
								trh_printf("Cascade level2 UID = %x, %x, %x, %x, %x \n", ACID2[0], ACID2[1], ACID2[2], ACID2[3], ACID2[4]);
							
							if(ISO14443A_AntiCollision(CMD_ISO14443A_AntiCollison_LVEL3) == RESPONSE_OK)
							{
								Cont = ISO14443A_SELECT(CMD_ISO14443A_AntiCollison_LVEL3);
								if(Cont == UID_NOT)
								{
									for(i=0; i<5; i++) ACID3[i] = ACID[i];
									trh_printf("Cascade level3 UID = %x, %x, %x, %x, %x \n", ACID3[0], ACID3[1], ACID3[2], ACID3[3], ACID3[4]);
									trh_printf("YOU Check ISO14443A & HardWare & Firmware\n");
								}
								else if(Cont == RESPONSE_OK)
								{
									for(i=0; i<5; i++) ACID3[i] = ACID[i];
									trh_printf("ISO14443A UID(3) = ");
									trh_printf("%x, %x, %x, %x, %x", ACID1[0], ACID1[1], ACID1[2], ACID1[3], ACID1[4]);
									trh_printf("%x, %x, %x, %x, %x", ACID2[0], ACID2[1], ACID2[2], ACID2[3], ACID2[4]);
									trh_printf("%x, %x, %x, %x, %x", ACID3[0], ACID3[1], ACID3[2], ACID3[3], ACID3[4]);
									trh_printf("\n");
									ISO14443A_HALT(CMD_ISO14443A_HLTA);
								}
								else 
								{
									trh_printf("ISO14443A Cascade level3 SELECT NO Response\n");
								}
							}
						}
						else if(Cont == RESPONSE_OK)
						{
							for(i=0; i<5; i++) ACID2[i] = ACID[i];
							trh_printf("ISO14443A UID(2) = ");
							trh_printf("%x, %x, %x, %x, %x", ACID1[0], ACID1[1], ACID1[2], ACID1[3], ACID1[4]);
							trh_printf("%x, %x, %x, %x, %x", ACID2[0], ACID2[1], ACID2[2], ACID2[3], ACID2[4]);
							trh_printf("\n");
							ISO14443A_HALT(CMD_ISO14443A_HLTA);
						}
						else 
						{
							trh_printf("ISO14443A Cascade level2 SELECT NO Response\n");
						}
					}
				}
				else if(Cont == RESPONSE_OK)
				{
					for(i=0; i<5; i++) ACID1[i] = ACID[i];
					trh_printf("ISO14443A UID(1) = ");
					trh_printf("%x, %x, %x, %x, %x", ACID1[0], ACID1[1], ACID1[2], ACID1[3], ACID1[4]);
					trh_printf("\n");
					ISO14443A_HALT(CMD_ISO14443A_HLTA);

					if(ACID1[0] || ACID1[1] || ACID1[2] || ACID1[3])
					{
						// card detect
						RFIDR.Status.UnDetect = 0;
						RFIDR.Count.UnDetect = 0;

						if(memcmp((void *)RFIDR.UID, ACID1, 4) != 0)
						{
							// new card
							for(i=0; i<4; i++) RFIDR.UID[i] = ACID1[i];
							RFIDR.Status.New = 1;
						}
						LED_On(LED_CH_RFID, 0);
					}
				}
				else 
				{
				//	trh_printf("ISO14443A SELECT NO Response\n");
				}
			}			
		}
		else
		{
			detect = 0;
			if(++RFIDR.Count.UnDetect > 20)			// about 250ms
			{
				if(RFIDR.Status.UnDetect == 0)
				{
					RFIDR.Status.UnDetect = 1;
					RFIDR.Status.New = 1;
					memset((void *)RFIDR.UID, 0, 4);
				}
				LED_Off(LED_CH_RFID);
			}

		}
	}
}

