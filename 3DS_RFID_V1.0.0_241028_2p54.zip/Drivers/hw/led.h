/**
  ****************************************************************************************************
  * @ File      led.h
  *
  * @ Project   RSS_MLS
  * @ Author    KOTECH, MR
  ****************************************************************************************************
  */

#ifndef LED_H_
#define LED_H_


/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"


/* Define ------------------------------------------------------------------*/
#define LED_MAX_CH			2

// On/Off
typedef enum _LED_OnType
{
	LED_OFF				= 0,
	LED_ON				= 1,
	LED_TOGGLE		= 2,
} e_LED_OnType;

typedef enum _LED_Ch
{
	LED_CH_STATUS		= 0,
	LED_CH_RFID			= 1,
} e_LED_Ch;

typedef struct _LED_Timer
{
	uint32_t	On;
	uint32_t	Toggle;

} s_LED_Timer;

typedef struct _LED_tbl
{
  GPIO_TypeDef 		*port;
  uint16_t      	pin;
  GPIO_PinState 	on_state;
  GPIO_PinState 	off_state;

  e_LED_OnType		OnType;
	uint32_t				OnTime;
	uint32_t				ToggleTime;
} s_LED_tbl;

/* Variable ------------------------------------------------------------------*/
typedef struct _LED_Info
{
	s_LED_Timer				Timer[LED_MAX_CH];

} s_LED_Info;

extern __IO s_LED_Info LED;


/* Macro ------------------------------------------------------------------*/


/* EFP ---------------------------------------------------------*/
extern void LED_Init(void);
extern void LED_On(e_LED_Ch ch, uint16_t ms);
extern void LED_Off(e_LED_Ch ch);
extern void LED_Toggle(e_LED_Ch ch, uint16_t ms);
extern void LED_Process(void);

#endif /* LED_H_ */
