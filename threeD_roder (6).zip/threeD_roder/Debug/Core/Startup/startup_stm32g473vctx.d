Core/Startup/startup_stm32g473vctx.o: \
 ../Core/Startup/startup_stm32g473vctx.s
