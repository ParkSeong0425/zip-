Core/Src/status.o: ../Core/Src/status.c ../Core/Inc/status.h \
 ../Core/Inc/run.h
../Core/Inc/status.h:
../Core/Inc/run.h:
